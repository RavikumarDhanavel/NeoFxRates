# Local Configuration

`application-local.yaml` contains the non-secret application configuration. Secrets are read from environment variables.

Required local variables:

```text
MYSQL_PASSWORD
INTEGRAL_LOGIN_USER
INTEGRAL_LOGIN_PASSWORD
INTEGRAL_HMAC_USERNAME
INTEGRAL_HMAC_SECRET
INTEGRAL_RATE_ENQUIRY_LOGIN_USER
INTEGRAL_RATE_ENQUIRY_LOGIN_PASSWORD
```

Optional variables:

```text
MYSQL_USERNAME                  # defaults to root
INTEGRAL_BASE_URL               # defaults to the configured UAT base URL
INTEGRAL_RATE_ENQUIRY_LOGIN_ORG # defaults to NEOFX
INTEGRAL_LOGIN_ORG              # defaults to NEOFX
```

The application uses the `local` profile by default. Deployment environments should activate their own profile and provide environment-specific values through the platform's secret/configuration management.
