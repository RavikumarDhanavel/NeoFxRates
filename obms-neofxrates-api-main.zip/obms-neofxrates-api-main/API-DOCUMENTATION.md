# Neo FX Rates API Documentation

## Swagger / OpenAPI

When the application is running, the interactive documentation is available at:

- Swagger UI: `/swagger-ui.html`
- OpenAPI JSON: `/v3/api-docs`

The endpoint descriptions are maintained directly on `NeoFxController` so the Swagger contract stays close to the public API.

## Public APIs

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/neoFx/indicativeFxRateEnquiry` | Request an indicative FX quote; OBDX can fall back to the latest H2 snapshot when Integral does not provide a usable quote. |
| POST | `/neoFx/dealBooking` | Accept a quote and query it once before returning the booking response. |
| GET | `/neoFx/rateExchange` | Return Integral market rates, or the retained H2 snapshot if Integral is unavailable. |
| POST | `/neoFx/directDeal` | Execute LOGIN -> PLACE ORDER -> QUERY ORDER -> BOOK TRADE using the Direct Deal SSO token. |

## Error contract

All controller-level failures are normalized through `GlobalExceptionHandler` and returned as `ApiErrorResponse` with:

- timestamp
- HTTP status
- error
- application error code
- safe message
- request path
- request ID

## Logging and Splunk correlation

Audited API requests receive an `X-Request-ID`. If the caller already sends `X-Request-ID` or `X-Correlation-ID`, that identifier is reused; otherwise the application generates one.

The request ID is placed in SLF4J MDC and included in the console log pattern. Search Splunk using the request ID to follow the request through controller, service, Integral workflow, fallback and error logs.

Credentials, HMAC secrets and SSO tokens are not written to application logs. Audit payloads mask configured sensitive fields before persistence.

## Configuration

Environment-specific values are maintained in `application-local.yaml` (or the equivalent environment profile), including:

- MySQL and H2 datasource settings
- Integral base URL and endpoint paths
- Integral login credentials
- HMAC settings
- Rate Enquiry dataset and timeouts
- scheduler interval
- Integral processing delay
- audit configuration
- Swagger paths

Production deployments should provide credentials/secrets through environment-specific secret management rather than committing secrets to source control.
