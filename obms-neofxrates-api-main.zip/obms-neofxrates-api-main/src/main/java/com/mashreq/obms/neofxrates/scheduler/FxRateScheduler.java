package com.mashreq.obms.neofxrates.scheduler;

import com.mashreq.obms.neofxrates.service.FxRateEnquiryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "fx.scheduler", name = "enabled", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
@Slf4j
public class FxRateScheduler {

    private final FxRateEnquiryService fxRateEnquiryService;

    /**
     * Runs after the previous execution has completed, then waits for the
     * configured delay before starting the next refresh.
     *
     * <p>The configured delay is 15 minutes by default in the local profile. This follows the same
     * fixed-delay scheduling model used by the reference Rate Enquiry project.</p>
     */
    @Scheduled(fixedDelayString = "${fx.scheduler.rate-fetch-delay-ms}")
    public void fetchRates() {

        long startTime = System.currentTimeMillis();

        log.info("FX Rate Scheduler started");

        try {
            fxRateEnquiryService.refreshRates();

            long duration = System.currentTimeMillis() - startTime;

            log.info(
                    "FX Rate Scheduler completed successfully in {} ms. "
                            + "Next execution will start after the configured fixed delay.",
                    duration
            );

        } catch (RuntimeException ex) {

            long duration = System.currentTimeMillis() - startTime;

            log.error(
                    "FX Rate Scheduler refresh failed after {} ms. "
                            + "Existing H2 rates will be retained. "
                            + "Scheduler will continue with the next fixed-delay execution.",
                    duration,
                    ex
            );
        }
    }
}
