package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/** Configurable defaults used to build Integral Request Quote payloads. */
@Configuration
@ConfigurationProperties(prefix = "app.request-quote")
@Getter
@Setter
public class RequestQuoteProperties {

    private boolean rfq;
    private int expiry;
    private String priceType;
    private String customerAccount;
    private String customerOrg;
    private String nearValueDate;
    private String sellSide;
    private String buySide;
}
