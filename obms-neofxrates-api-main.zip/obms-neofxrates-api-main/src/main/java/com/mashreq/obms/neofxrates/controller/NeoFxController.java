package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingResponse;
import com.mashreq.obms.neofxrates.dto.DirectDealRequest;
import com.mashreq.obms.neofxrates.dto.DirectDealResponse;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.dto.RateEnquiryResponse;
import com.mashreq.obms.neofxrates.service.DealBookingService;
import com.mashreq.obms.neofxrates.service.DirectDealService;
import com.mashreq.obms.neofxrates.service.FxRateEnquiryService;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${app.api.base-path}")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Neo FX", description = "Foreign-exchange rate enquiry, deal booking and direct-deal APIs")
public class NeoFxController {

    private final IndicativeFxRateService indicativeFxRateService;
    private final DealBookingService dealBookingService;
    private final DirectDealService directDealService;
    private final FxRateEnquiryService fxRateEnquiryService;

    @PostMapping("/indicativeFxRateEnquiry")
    @Operation(summary = "Indicative FX rate enquiry", description = "Requests an Integral quote and returns the indicative FX response. OBDX requests may use the latest H2 snapshot when Integral does not provide a usable quote.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Indicative rate returned"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class))),
            @ApiResponse(responseCode = "502", description = "Integral/H2 fallback failure", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class)))
    })
    public ResponseEntity<IndicativeFxRateEnquiryResponse> indicativeFxRateEnquiry(
            @RequestBody IndicativeFxRateEnquiryRequest request) {
        log.info("Received indicative FX rate enquiry");
        return indicativeFxRateService.fetchFxRate(request);
    }

    @PostMapping("/dealBooking")
    @Operation(summary = "Book an FX deal", description = "Accepts the quote and performs one Query Quote call before returning the deal-booking response.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Deal booking response returned"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class))),
            @ApiResponse(responseCode = "502", description = "Integral API failure", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class)))
    })
    public ResponseEntity<DealBookingResponse> dealBooking(@RequestBody DealBookingRequest request) {
        log.info("Received deal booking request");
        return dealBookingService.dealBooking(request);
    }

    @GetMapping("/rateExchange")
    @Operation(summary = "Get FX rate exchange data", description = "Returns the latest Integral market dataset. If Integral is unavailable, the latest successful H2 snapshot is returned.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rates returned"),
            @ApiResponse(responseCode = "502", description = "No upstream or cached rates available", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class)))
    })
    public ResponseEntity<RateEnquiryResponse> rateExchange() {
        log.info("Received rate exchange request");
        return ResponseEntity.ok(fxRateEnquiryService.fetchRatesWithFallback());
    }

    @PostMapping("/directDeal")
    @Operation(summary = "Execute a direct FX deal", description = "Runs LOGIN, PLACE ORDER, QUERY ORDER and BOOK TRADE using the Integral SSO token for the Direct Deal flow.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Direct deal response returned"),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class))),
            @ApiResponse(responseCode = "502", description = "Integral API failure", content = @Content(schema = @Schema(implementation = com.mashreq.obms.neofxrates.exception.ApiErrorResponse.class)))
    })
    public ResponseEntity<DirectDealResponse> directDeal(@RequestBody DirectDealRequest request) {
        log.info("Received direct deal request");
        return directDealService.directDeal(request);
    }
}
