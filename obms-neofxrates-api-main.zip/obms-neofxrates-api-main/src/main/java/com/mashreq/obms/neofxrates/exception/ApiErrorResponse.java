package com.mashreq.obms.neofxrates.exception;

import java.time.OffsetDateTime;

/** Standard error response returned by every REST endpoint. */
public record ApiErrorResponse(
        OffsetDateTime timestamp,
        int status,
        String error,
        String code,
        String message,
        String path,
        String requestId) {
}
