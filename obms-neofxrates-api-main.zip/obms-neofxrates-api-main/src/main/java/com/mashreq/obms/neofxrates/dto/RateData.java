package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RateData {
    private String status;
    private String rateId;
    private String tenor;
    private String currencyPair;
    private BigDecimal bid;
    private BigDecimal mid;
    private BigDecimal offer;
    private String baseCurrency;
    private String termCurrency;
    private String bidLastUpdatedTime;
    private String offerLastUpdatedTime;
    private String midLastUpdatedTime;
}
