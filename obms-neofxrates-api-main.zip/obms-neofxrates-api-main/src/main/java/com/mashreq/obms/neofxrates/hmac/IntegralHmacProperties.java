package com.mashreq.obms.neofxrates.hmac;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.hmac")
@Getter
@Setter
public class IntegralHmacProperties {

    private boolean enabled;
    private String username;
    private String secret;
    private String secretEncoding;
    private String stripPathPrefix;
    private String headers;
    private String bodyLineEnding;
}
