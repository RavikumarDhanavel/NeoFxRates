package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Runtime settings for the Indicative FX fallback response. */
@Configuration
@ConfigurationProperties(prefix = "app.indicative-fx")
@Getter
@Setter
public class IndicativeFxProperties {

    private boolean fallbackEnabled;
    private List<String> fallbackSources = new ArrayList<>();
    private String fallbackProvider;
    private BigDecimal fallbackForwardPoint;
    private int fallbackEffectiveTime;
    private String fallbackQuoteStatus;
}
