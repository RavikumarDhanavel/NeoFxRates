package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Slf4j
public class FxIntegralQueryOrderApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;
    private final EndpointsConfig endpointsConfig;

    /** Existing HMAC-authenticated Query Order call. */
    public ResponseEntity<String> queryOrder(String orderId) {
        return exchange(orderId, null);
    }

    /** Direct Deal Query Order using the SSO_TOKEN returned by Direct Deal login. */
    public ResponseEntity<String> queryOrderWithSso(
            String orderId,
            String ssoToken) {
        return exchange(orderId, ssoToken);
    }

    private ResponseEntity<String> exchange(String orderId, String ssoToken) {
        String url = applicationConfig.getBaseUrl() + endpointsConfig.getQueryOrder() + orderId;

        HttpHeaders headers = new HttpHeaders();
        if (ssoToken != null && !ssoToken.isBlank()) {
            headers.set("SSO_TOKEN", ssoToken);
            headers.set(IntegralHmacInterceptor.SKIP_HMAC_HEADER, "true");
        }

        log.info("Calling Integral QUERY ORDER. orderId={}, ssoAuthentication={}", orderId, ssoToken != null && !ssoToken.isBlank());
        ResponseEntity<String> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class);
        log.info("Integral QUERY ORDER completed. orderId={}, httpStatus={}", orderId, response.getStatusCode().value());
        return response;
    }
}
