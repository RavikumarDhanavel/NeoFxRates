package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration for the background FX rate snapshot refresh.
 */
@Configuration
@ConfigurationProperties(prefix = "app.rate-enquiry")
@Getter
@Setter
public class RateEnquiryProperties {

    private String datasetId;
    private String path;

    private Login login = new Login();

    /**
     * HTTP timeout values follow the reference Rate Enquiry project.
     * They prevent a blocked Integral request from holding the scheduler
     * thread indefinitely.
     */
    private int connectTimeoutMs;
    private int readTimeoutMs;

    @Getter
    @Setter
    public static class Login {
        private String user;
        private String pass;
        private String org;
    }
}
