package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.RateEnquiryProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

/**
 * Calls Integral Rate Enquiry using the SSO token obtained from LOGIN.
 */
@Service
@Slf4j
public class FxIntegralRateEnquiryApi {

    private final ApplicationConfig applicationConfig;
    private final RateEnquiryProperties properties;
    private final RestTemplate rateEnquiryRestTemplate;

    public FxIntegralRateEnquiryApi(
            ApplicationConfig applicationConfig,
            RateEnquiryProperties properties,
            @Qualifier("rateEnquiryRestTemplate")
            RestTemplate rateEnquiryRestTemplate) {
        this.applicationConfig = applicationConfig;
        this.properties = properties;
        this.rateEnquiryRestTemplate = rateEnquiryRestTemplate;
    }

    public ResponseEntity<String> fetchRates(String ssoToken) {
        log.info("Calling Integral RATE ENQUIRY. datasetId={}", properties.getDatasetId());

        if (ssoToken == null || ssoToken.isBlank()) {
            throw new IllegalArgumentException(
                    "SSO_TOKEN is required for Rate Enquiry");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.set("SSO_TOKEN", ssoToken);

        String url = applicationConfig.getBaseUrl() + properties.getPath() + "?id=" + properties.getDatasetId();

        return rateEnquiryRestTemplate.exchange(url, HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class);
    }
}
