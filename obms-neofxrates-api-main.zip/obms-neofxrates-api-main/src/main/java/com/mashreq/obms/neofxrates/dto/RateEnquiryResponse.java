package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.util.List;

@Data
public class RateEnquiryResponse {
    private List<MarketDataSet> marketDataSets;
}
