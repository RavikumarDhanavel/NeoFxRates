package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
@Slf4j
public class FxIntegralLoginApi {

    private final ApplicationConfig applicationConfig;
    private final EndpointsConfig endpointsConfig;
    private final RestTemplate restTemplate;

    public FxIntegralLoginApi(
            ApplicationConfig applicationConfig,
            EndpointsConfig endpointsConfig,
            RestTemplate restTemplate) {
        this.applicationConfig = applicationConfig;
        this.endpointsConfig = endpointsConfig;
        this.restTemplate = restTemplate;
    }

    /**
     * HMAC-authenticated LOGIN used by the existing RFQ/indicative flow.
     */
    public ResponseEntity<LoginResponse> login(LoginRequest request) {
        log.info("Calling Integral LOGIN for configured RFQ flow. org={}", request.getOrg());

        return exchangeLogin(restTemplate, request, false);
    }

    /**
     * Direct Deal LOGIN. The existing Direct Deal SSO flow skips HMAC.
     */
    public ResponseEntity<LoginResponse> loginForDirectDeal(LoginRequest request) {
        log.info("Calling Integral LOGIN for Direct Deal. org={}", request.getOrg());

        return exchangeLogin(restTemplate, request, true);
    }

    /**
     * LOGIN for the background Rate Enquiry flow.
     *
     * <p>LOGIN remains HMAC-authenticated; the returned SSO_TOKEN is then used
     * by the dedicated non-HMAC Rate Enquiry client.</p>
     */
    public ResponseEntity<LoginResponse> loginForRateEnquiry(LoginRequest request) {
        log.info("Calling Integral LOGIN for Rate Enquiry. org={}", request.getOrg());

        // Integral SSO LOGIN requires the same HMAC authentication as the
        // existing Integral login flow. The SSO_TOKEN returned by this call
        // is then used by the dedicated non-HMAC Rate Enquiry client.
        return exchangeLogin(restTemplate, request, false);
    }

    private ResponseEntity<LoginResponse> exchangeLogin(
            RestTemplate client,
            LoginRequest request,
            boolean skipHmac) {

        HttpHeaders headers = createHeaders();

        if (skipHmac) {
            headers.set(
                    IntegralHmacInterceptor.SKIP_HMAC_HEADER,
                    Boolean.TRUE.toString());
        }

        HttpEntity<LoginRequest> entity =
                new HttpEntity<>(request, headers);

        return client.exchange(
                buildLoginUrl(),
                HttpMethod.POST,
                entity,
                LoginResponse.class);
    }

    private String buildLoginUrl() {
        return applicationConfig.getBaseUrl()
                + endpointsConfig.getSsoLogin();
    }

    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        return headers;
    }
}
