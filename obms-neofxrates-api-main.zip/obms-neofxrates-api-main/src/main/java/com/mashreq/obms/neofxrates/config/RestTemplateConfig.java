package com.mashreq.obms.neofxrates.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configuration
public class RestTemplateConfig {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public IntegralHmacService integralHmacService(
            IntegralHmacProperties hmacProperties) {
        return new IntegralHmacService(hmacProperties);
    }

    /**
     * Existing RestTemplate used by the HMAC-authenticated Integral APIs.
     *
     * <p>Connect/read timeouts are configured so an unavailable or stalled
     * Integral endpoint cannot block the scheduler indefinitely.</p>
     */
    @Bean
    public RestTemplate restTemplate(
            IntegralHmacProperties hmacProperties,
            IntegralHmacService hmacService,
            RateEnquiryProperties rateEnquiryProperties) {

        RestTemplate restTemplate = createRestTemplate(rateEnquiryProperties);

        restTemplate.getInterceptors().add(
                new IntegralHmacInterceptor(hmacProperties, hmacService));

        return restTemplate;
    }

    /**
     * Dedicated client for the SSO-based Rate Enquiry GET.
     *
     * <p>This client intentionally has no HMAC interceptor. LOGIN still uses
     * the existing HMAC RestTemplate; the SSO_TOKEN returned by LOGIN is then
     * sent to the Rate Enquiry endpoint without an HMAC Authorization header,
     * matching the reference flow.</p>
     */
    @Bean(name = "rateEnquiryRestTemplate")
    public RestTemplate rateEnquiryRestTemplate(
            RateEnquiryProperties rateEnquiryProperties) {

        return createRestTemplate(rateEnquiryProperties);
    }

    private RestTemplate createRestTemplate(
            RateEnquiryProperties properties) {

        SimpleClientHttpRequestFactory requestFactory =
                new SimpleClientHttpRequestFactory();

        requestFactory.setConnectTimeout(
                Duration.ofMillis(properties.getConnectTimeoutMs()));

        requestFactory.setReadTimeout(
                Duration.ofMillis(properties.getReadTimeoutMs()));

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setRequestFactory(requestFactory);

        return restTemplate;
    }
}
