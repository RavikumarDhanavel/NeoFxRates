package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.IndicativeFxProperties;
import com.mashreq.obms.neofxrates.config.IntegralFlowProperties;
import com.mashreq.obms.neofxrates.config.RequestQuoteProperties;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.QueryQuoteRequestBody;
import com.mashreq.obms.neofxrates.dto.RateData;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.exception.ValidationUtils;
import com.mashreq.obms.neofxrates.model.IndicativeFxContext;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRequestQuoteApi;
import com.mashreq.obms.neofxrates.repository.FxRateSnapshotRepository;
import com.mashreq.obms.neofxrates.repository.TraditionalCurrencyPairDirectionRepository;
import jakarta.validation.constraints.Null;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
@Slf4j
public class IndicativeFxRateService {


    private final FxIntegralRequestQuoteApi requestQuoteApi;
    private final FxIntegralQueryQuoteApi queryQuoteApi;
    private final TraditionalCurrencyPairDirectionRepository currencyPairRepository;
    private final FxRateSnapshotRepository fxRateSnapshotRepository;
    private final ObjectMapper objectMapper;
    private final IntegralFlowProperties integralFlowProperties;
    private final IndicativeFxProperties indicativeFxProperties;
    private final RequestQuoteProperties requestQuoteProperties;

    public ResponseEntity<IndicativeFxRateEnquiryResponse> fetchFxRate(IndicativeFxRateEnquiryRequest request) {
        reqValidate(request);
        log.info("Starting indicative FX flow. source={}, refNo={}, debitCurrency={}, transferCurrency={}",
                request.getSource(), request.getRefNo(), request.getDebitCurrency(), request.getTransferCurrency());
        // Resolve the configured Integral symbol before making any outbound call.
        // The database always stores the strong/base currency first and the
        // weak/quote currency second.
        TraditionalCurrencyPairDirection pair = resolveCurrencyPair(request);
        String symbol = pair.getBaseCurrency() + "/" + pair.getQuoteCurrency();
        log.info("Resolved Integral currency pair. symbol={}", symbol);
        IndicativeFxContext context = new IndicativeFxContext();
        context.setClOrderId(request.getRefNo());

        // REQUEST QUOTE - symbol comes from the database, not a hard-coded value.
        RequestQuoteRequest requestQuoteRequest =
                new RequestQuoteRequest().buildReq(request, symbol, requestQuoteProperties);

        /*
         * Keep the existing Integral happy flow unchanged. The H2 fallback is
         * deliberately limited to OBDX. OBPAY and every other source continue
         * through the existing Integral-only path.
         */
        try {
            call("REQUEST_QUOTE", () -> {
                ResponseEntity<RequestQuoteResponse> response =
                        requestQuoteApi.requestQuote(requestQuoteRequest);
                if (response == null) {
                    throw new RequestQuoteException("REQUEST_QUOTE", HttpStatus.BAD_GATEWAY, "Integral returned empty response");
                }
                if (response.getStatusCode().value() != 202) {
                    throw new RequestQuoteException("REQUEST_QUOTE", response.getStatusCode(),
                            "Request Quote did not return HTTP 202");
                }
                RequestQuoteResponse body = response.getBody();
                if (body == null || body.getRequestId() == null || body.getRequestId().isBlank()) {
                    throw new RequestQuoteException("REQUEST_QUOTE", HttpStatus.BAD_GATEWAY,
                            "Request Quote did not return requestId");
                }
                context.setRequestId(body.getRequestId());
                context.setClOrderId(body.getClOrderId());
                context.setEvent(body.getEvent());
                log.info("Integral REQUEST QUOTE accepted. requestId={}, clOrderId={}, event={}",
                        body.getRequestId(), body.getClOrderId(), body.getEvent());
                return body;
            });

            // Integral needs a short processing window before Query Quote.
            try {
                Thread.sleep(integralFlowProperties.getQueryQuoteDelayMs());
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.INTERNAL_SERVER_ERROR,
                        "Interrupted while waiting for Query Quote");
            }

            // QUERY QUOTE - exactly one call.
            ResponseEntity<String> queryQuoteResponse = call("QUERY_QUOTE", () -> {
                ResponseEntity<String> response =
                        queryQuoteApi.queryByClientId(context.getClOrderId());
                if (response == null) {
                    throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                            "Integral returned empty Query Quote response");
                }
                if (!response.getStatusCode().is2xxSuccessful()) {
                    throw new RequestQuoteException("QUERY_QUOTE", response.getStatusCode(),
                            "Integral Query Quote failed");
                }
                if (response.getBody() == null || response.getBody().isBlank()) {
                    throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                            "Integral returned empty Query Quote body");
                }
                return response;
            });

            IndicativeFxRateEnquiryResponse tsdResponse = buildTsdResponse(
                    queryQuoteResponse.getBody(), request, requestQuoteRequest);

            /*
             * A 2xx response is not sufficient by itself. If Integral returned
             * a non-QUOTE/event response, treat it as an unsuccessful indicative
             * rate and allow the OBDX fallback to handle it.
             */
            if (isSuccessfulIndicativeRate(tsdResponse)) {
                log.info("Integral indicative FX quote returned successfully. refNo={}, status={}",
                        request.getRefNo(), queryQuoteResponse.getStatusCode().value());
                return ResponseEntity.status(queryQuoteResponse.getStatusCode()).body(tsdResponse);
            }

            if (isFallbackSource(request)) {
                log.warn("Integral did not return a successful indicative FX rate for OBDX refNo={}. Using latest H2 rate snapshot.",
                        request.getRefNo());
                log.info("Returning H2 fallback rate. refNo={}, symbol={}", request.getRefNo(), symbol);
                return ResponseEntity.ok(buildH2FallbackResponse(request, requestQuoteRequest, symbol));
            }

            return ResponseEntity.status(queryQuoteResponse.getStatusCode()).body(tsdResponse);

        } catch (RequestQuoteException ex) {
            if (isFallbackSource(request)) {
                log.warn("Integral indicative FX flow failed for OBDX refNo={}. Using latest H2 rate snapshot. step={}, message={}",
                        request.getRefNo(), ex.getStep(), ex.getMessage());
                log.info("Returning H2 fallback rate. refNo={}, symbol={}", request.getRefNo(), symbol);
                return ResponseEntity.ok(buildH2FallbackResponse(request, requestQuoteRequest, symbol));
            }
            throw ex;
        }
    }

    private TraditionalCurrencyPairDirection resolveCurrencyPair(
            IndicativeFxRateEnquiryRequest request) {
        String debitCurrency = normalizeCurrency(request.getDebitCurrency());
        String transferCurrency = normalizeCurrency(request.getTransferCurrency());

        // First try the request direction. If found, Integral receives BASE/QUOTE
        // exactly as stored in the database.
        return currencyPairRepository
                .findByBaseCurrencyAndQuoteCurrency(debitCurrency, transferCurrency)
                .orElseGet(() -> currencyPairRepository
                        .findByBaseCurrencyAndQuoteCurrency(transferCurrency, debitCurrency)
                        .orElseThrow(() -> new RequestQuoteException("CURRENCY_PAIR",
                                HttpStatus.BAD_REQUEST, "No currency pair configured for "
                                        + debitCurrency + "/" + transferCurrency)));
    }

    private IndicativeFxRateEnquiryResponse buildTsdResponse(String integralResponse, IndicativeFxRateEnquiryRequest request,
            RequestQuoteRequest requestQuoteRequest) {

        try {
            Map<String, Object> integralRoot = objectMapper.readValue(
                    integralResponse, new TypeReference<Map<String, Object>>() {});
            if (integralRoot == null || integralRoot.isEmpty()) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral Query Quote response is empty");
            }
            Object upstreamData = integralRoot.get("data");
            Map<String, Object> data;
            if (upstreamData instanceof Map<?, ?>) {
                data = toStringObjectMap((Map<?, ?>) upstreamData);
            } else {
                data = new LinkedHashMap<>(integralRoot);
            }
            data.put("cachedRate", "N");
            data.put("side", requestQuoteRequest.getSide());
            data.put("rfq", requestQuoteRequest.getRfq());

            // Integral only accepts the configured BASE/QUOTE direction. Therefore:
            // Base = dealt currency -> Normal -> N
            // Quote = dealt currency -> Inverse -> Y
            String inverse = isInverse(requestQuoteRequest.getDealtCurrency(),
                    requestQuoteRequest.getSymbol()) ? "Y" : "N";
            data.put("inverse", inverse);
            calculateReciprocalRateAndSettledAmount(data, inverse);
            IndicativeFxRateEnquiryResponse response = new IndicativeFxRateEnquiryResponse();
            response.setData(data);
            response.setRequestBody(QueryQuoteRequestBody.from(request));
            return response;
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (JsonProcessingException | IllegalArgumentException ex) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Query Quote response: " + ex.getMessage());
        }
    }

    private boolean isFallbackSource(IndicativeFxRateEnquiryRequest request) {
        return indicativeFxProperties.isFallbackEnabled()
                && request != null
                && request.getSource() != null
                && indicativeFxProperties.getFallbackSources().stream()
                .anyMatch(source -> source.equalsIgnoreCase(request.getSource().trim()));
    }

    /**
     * Integral can return a technically successful HTTP response which is not
     * an actual indicative quote. Only a QUOTE response containing at least
     * one quote/offer is considered a successful indicative FX response.
     */
    private boolean isSuccessfulIndicativeRate(IndicativeFxRateEnquiryResponse response) {
        if (response == null || response.getData() == null) {
            return false;
        }

        Map<String, Object> data = response.getData();
        if (!"QUOTE".equalsIgnoreCase(String.valueOf(data.get("event")))) {
            return false;
        }

        Object quotesObject = data.get("quotes");
        if (!(quotesObject instanceof List<?> quotes) || quotes.isEmpty()) {
            return false;
        }

        for (Object quoteObject : quotes) {
            if (!(quoteObject instanceof Map<?, ?> quote)) {
                continue;
            }

            // Integral can return the selected market side as either BID or
            // OFFER. Both are valid indicative quote structures.
            if (hasValidRate(quote.get("offers")) || hasValidRate(quote.get("bids"))) {
                return true;
            }
        }
        return false;
    }

    private boolean hasValidRate(Object legsObject) {
        if (!(legsObject instanceof List<?> legs) || legs.isEmpty()) {
            return false;
        }

        for (Object legObject : legs) {
            if (legObject instanceof Map<?, ?> leg) {
                BigDecimal rate = toBigDecimal(leg.get("rate"));
                if (rate != null && rate.compareTo(BigDecimal.ZERO) > 0) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * Builds the same TSD response envelope used by the Integral happy flow,
     * but sources the market rate from the latest scheduler-maintained H2
     * snapshot. No H2 value is returned directly to the controller.
     */
    private IndicativeFxRateEnquiryResponse buildH2FallbackResponse(
            IndicativeFxRateEnquiryRequest request,
            RequestQuoteRequest requestQuoteRequest,
            String symbol) {

        RateData storedRate = fxRateSnapshotRepository.findByCurrencyPair(symbol)
                .orElseThrow(() -> new RequestQuoteException(
                        "H2_FALLBACK",
                        HttpStatus.BAD_GATEWAY,
                        "No cached FX rate available in H2 for " + symbol));

        boolean inverse = isInverse(requestQuoteRequest.getDealtCurrency(), requestQuoteRequest.getSymbol());

        boolean useBid = shouldUseBid(requestQuoteRequest.getSide(), inverse);
        BigDecimal rate = selectFallbackRate(storedRate, requestQuoteRequest.getSide(), inverse);

        if (rate == null || rate.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RequestQuoteException("H2_FALLBACK", HttpStatus.BAD_GATEWAY,
                    "Cached FX rate is missing or invalid for " + symbol);
        }

        /*
         * Keep the fallback quote contract aligned with a successful Integral
         * QUOTE response. The market rate itself comes from H2; the surrounding
         * fields are populated from the same Request Quote context used by the
         * normal Integral flow.
         */
        /*
         * Mirror the selected market side returned by Integral:
         * BID   -> "bids": [{ "type": "BID", ... }]
         * OFFER -> "offers": [{ "type": "OFFER", ... }]
         */
        Map<String, Object> selectedLeg = new LinkedHashMap<>();
        selectedLeg.put("legType", null);
        selectedLeg.put("quoteId", null);
        selectedLeg.put("type", useBid ? "BID" : "OFFER");
        selectedLeg.put("dealtAmount", requestQuoteRequest.getAmount());
        selectedLeg.put("provider", indicativeFxProperties.getFallbackProvider());
        selectedLeg.put("rate", normalizeNumber(rate));
        selectedLeg.put("spotRate", normalizeNumber(rate));
        selectedLeg.put("forwardPoint", null);
        selectedLeg.put("midRate", normalizeNumber(storedRate.getMid()));

        Map<String, Object> quote = new LinkedHashMap<>();
        quote.put("requestId", null);
        quote.put("priceType", requestQuoteRequest.getPriceType());
        quote.put("effectiveTime", null);
        quote.put("symbol", symbol);
        quote.put("ttl", requestQuoteRequest.getExpiry());
        quote.put("dealtCurrency", requestQuoteRequest.getDealtCurrency());
        quote.put("status", null);
        quote.put("nearValueDate", null);
        quote.put(useBid ? "bids" : "offers", List.of(selectedLeg));

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("clOrderId", request.getRefNo());
        data.put("requestId", null);
        data.put("transactionId", null);
        data.put("ttl", requestQuoteRequest.getExpiry());
        data.put("event", "QUOTE");
        data.put("quotes", new ArrayList<>(List.of(quote)));
        data.put("cachedRate", "Y");
        data.put("side", requestQuoteRequest.getSide());
        data.put("rfq", requestQuoteRequest.getRfq());
        data.put("inverse", inverse ? "Y" : "N");

        /*
         * Reuse the exact calculation already applied to a successful Integral
         * response so H2 fallback and Integral responses follow identical
         * reciprocalRate/settledAmount rules.
         */
        calculateReciprocalRateAndSettledAmount(data, inverse ? "Y" : "N");

        IndicativeFxRateEnquiryResponse response = new IndicativeFxRateEnquiryResponse();
        response.setData(data);
        response.setRequestBody(QueryQuoteRequestBody.from(request));
        return response;
    }

    /**
     * Selects the customer-facing side of the cached market pair.
     *
     * Normal pair (dealt = base):
     *   SELL -> bid, BUY -> offer.
     * Inverse pair (dealt = quote):
     *   SELL -> offer, BUY -> bid.
     */
    private BigDecimal selectFallbackRate(RateData storedRate, String side, boolean inverse) {

        return shouldUseBid(side, inverse) ? storedRate.getBid() : storedRate.getOffer();
    }

    /**
     * Cached-rate selection:
     *
     * Base  + BUY  -> OFFER
     * Base  + SELL -> BID
     * Quote + BUY  -> BID
     * Quote + SELL -> OFFER
     */
    private boolean shouldUseBid(String side, boolean inverse) {
        boolean buy = "BUY".equalsIgnoreCase(side);
        return inverse ? buy : !buy;
    }

    private boolean isInverse(String dealtCurrency, String symbol) {
        if (dealtCurrency == null || symbol == null || !symbol.contains("/")) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to determine inverse direction");
        }

        String[] currencies = symbol.split("/", -1);
        String baseCurrency = normalizeCurrency(currencies[0]);
        String quoteCurrency = normalizeCurrency(currencies[1]);
        String normalizedDealt = normalizeCurrency(dealtCurrency);

        if (baseCurrency.equals(normalizedDealt)) {
            return false;
        }
        if (quoteCurrency.equals(normalizedDealt)) {
            return true;
        }
        throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                "Dealt currency " + normalizedDealt + " is not part of currency pair " + symbol);
    }

    /**
     * Calculates TSD reciprocalRate and replaces each Integral settledAmount
     * using the documented normal/inverse formula.
     *
     * Normal (inverse=N): settledAmount = dealtAmount * rate
     * Inverse (inverse=Y): settledAmount = dealtAmount / rate
     * reciprocalRate = 1 / rate
     */
    private void calculateReciprocalRateAndSettledAmount(
            Map<String, Object> data, String inverse) {
        Object quotesObject = data.get("quotes");
        if (!(quotesObject instanceof List<?> quotes)) {
            data.put("reciprocalRate", null);
            return;
        }

        List<Object> mutableQuotes = new ArrayList<>(quotes);
        BigDecimal firstRate = null;
        for (int quoteIndex = 0; quoteIndex < quotes.size(); quoteIndex++) {
            Object quoteObject = quotes.get(quoteIndex);
            if (!(quoteObject instanceof Map<?, ?> quoteMapRaw)) {
                continue;
            }
            Map<String, Object> quoteMap = toStringObjectMap(quoteMapRaw);
            boolean processedLegs = false;

            // Preserve the original Integral structure. The quote may contain
            // either an "offers" array or a "bids" array.
            for (String legKey : List.of("offers", "bids")) {
                Object legsObject = quoteMap.get(legKey);
                if (!(legsObject instanceof List<?> legs)) {
                    continue;
                }

                List<Object> updatedLegs = new ArrayList<>();
                for (Object legObject : legs) {
                    if (!(legObject instanceof Map<?, ?> legMapRaw)) {
                        updatedLegs.add(legObject);
                        continue;
                    }

                    Map<String, Object> legMap = toStringObjectMap(legMapRaw);
                    BigDecimal rate = toBigDecimal(legMap.get("rate"));
                    BigDecimal dealtAmount = toBigDecimal(legMap.get("dealtAmount"));

                    if (rate == null || rate.compareTo(BigDecimal.ZERO) <= 0) {
                        throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                                "Integral quote contains missing or invalid rate");
                    }

                    if (firstRate == null) {
                        firstRate = rate;
                    }

                    if (dealtAmount != null) {
                        BigDecimal settledAmount;
                        if ("Y".equals(inverse)) {
                            settledAmount = dealtAmount.divide(rate, 10, RoundingMode.HALF_UP);
                        } else {
                            settledAmount = dealtAmount.multiply(rate);
                        }
                        legMap.put("settledAmount", normalizeNumber(settledAmount));
                    }
                    updatedLegs.add(legMap);
                }

                quoteMap.put(legKey, updatedLegs);
                processedLegs = true;
            }

            if (!processedLegs) {
                continue;
            }

            mutableQuotes.set(quoteIndex, quoteMap);
        }

        data.put("quotes", mutableQuotes);
        data.put("reciprocalRate",
                firstRate == null ? null : normalizeNumber(
                        BigDecimal.ONE.divide(firstRate, 10, RoundingMode.HALF_UP)));
    }

    private BigDecimal toBigDecimal(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof BigDecimal decimal) {
            return decimal;
        }
        if (value instanceof Number number) {
            return BigDecimal.valueOf(number.doubleValue());
        }
        if (value instanceof String string && !string.isBlank()) {
            try {
                return new BigDecimal(string.trim());
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        return null;
    }

    private Number normalizeNumber(BigDecimal value) {
        if (value == null) {
            return null;
        }
        BigDecimal normalized = value.stripTrailingZeros();
        if (normalized.scale() < 0) {
            normalized = normalized.setScale(0);
        }
        return normalized;
    }

    private Map<String, Object> toStringObjectMap(Map<?, ?> source) {
        Map<String, Object> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(String.valueOf(key), value));
        return result;
    }

    private <T> T call(String step, Supplier<T> action) {
        try {
            return action.get();
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (RestClientResponseException ex) {
            throw new RequestQuoteException(step, ex.getStatusCode(),
                    "Integral API returned HTTP " + ex.getStatusCode().value());
        } catch (RestClientException | IllegalArgumentException ex) {
            throw new RequestQuoteException(step, HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral API: " + ex.getMessage());
        }
    }
    private void reqValidate(IndicativeFxRateEnquiryRequest request) {
        require(request.getDebitCurrency(), "debitCurrency");
        require(request.getTransferCurrency(), "transferCurrency");
        require(request.getPayByIndicator(), "payByIndicator");
        if (!"D".equalsIgnoreCase(request.getPayByIndicator())
                && !"T".equalsIgnoreCase(request.getPayByIndicator())) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "payByIndicator must be D or T");
        }
        if (request.getTransactionAmount() == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "transactionAmount is required");
        }
    }

    private void require(String value, String field) {
        ValidationUtils.requireText(value, field);
    }

    private String normalizeCurrency(String currency) {
        return currency.trim().toUpperCase(java.util.Locale.ROOT);
    }
}
