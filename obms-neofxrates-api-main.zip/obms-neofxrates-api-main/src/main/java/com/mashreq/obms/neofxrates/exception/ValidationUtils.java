package com.mashreq.obms.neofxrates.exception;

import org.springframework.http.HttpStatus;

import java.math.BigDecimal;

/** Shared validation helpers used by the service layer. */
public final class ValidationUtils {

    private ValidationUtils() {
    }

    public static void requireText(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }

    public static void requirePositive(BigDecimal value, String field) {
        if (value == null || value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    field + " must be greater than zero");
        }
    }

    public static void requirePresent(Object value, String field) {
        if (value == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }
}
