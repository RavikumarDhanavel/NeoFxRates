package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.util.List;

@Data
public class MarketDataSet {
    private String id;
    private String date;
    private String timeWindow;
    private String name;
    private String createdTime;
    private String activationTime;
    private String validUntil;
    private String nextCreationTime;
    private String expirationTime;
    private List<RateData> rates;
}
