package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.RateEnquiryProperties;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.dto.MarketDataSet;
import com.mashreq.obms.neofxrates.dto.RateData;
import com.mashreq.obms.neofxrates.dto.RateEnquiryResponse;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRateEnquiryApi;
import com.mashreq.obms.neofxrates.repository.FxRateSnapshotRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Orchestrates the background Integral LOGIN -> Rate Enquiry -> H2 snapshot
 * flow. No public/controller API is required for this flow.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FxRateEnquiryService {

    private final FxIntegralLoginApi loginApi;
    private final FxIntegralRateEnquiryApi rateEnquiryApi;
    private final FxRateSnapshotRepository snapshotRepository;
    private final RateEnquiryProperties properties;
    private final ObjectMapper objectMapper;
    private final TransactionTemplate fxRateH2TransactionTemplate;

    public RateEnquiryResponse fetchRatesWithFallback() {

        log.info(
                "Starting public FX rate enquiry with Integral-to-H2 fallback enabled"
        );

        try {
            String ssoToken = loginAndGetSsoToken();
           //String ssoToken ="oiedahgoihsrg"; // for testing fallback only

            ResponseEntity<String> response =
                    rateEnquiryApi.fetchRates(ssoToken);

            log.info(
                    "Integral Rate Enquiry completed. httpStatus={}",
                    response == null
                            ? "NO_RESPONSE"
                            : response.getStatusCode().value()
            );

            validateHttpResponse(response);

            RateEnquiryResponse rateResponse =
                    parseResponse(response.getBody());

            SnapshotData snapshotData =
                    extractSnapshotData(rateResponse);

            if (!snapshotData.rates().isEmpty()) {
                return rateResponse;
            }

            log.warn(
                    "Integral Rate Enquiry returned no usable rates. "
                            + "Falling back to H2 snapshot."
            );

        } catch (RuntimeException ex) {

            log.warn(
                    "Integral Rate Enquiry failed. "
                            + "Falling back to H2 snapshot.",
                    ex
            );
        }

        return buildH2FallbackResponse();
    }

    private RateEnquiryResponse buildH2FallbackResponse() {
        List<RateData> rates = snapshotRepository.findAllRates();
        if (rates.isEmpty()) {
            throw new RequestQuoteException("H2_FALLBACK", HttpStatus.BAD_GATEWAY,
                    "Integral Rate Enquiry failed and no cached FX rates are available in H2");
        }

        MarketDataSet dataSet = new MarketDataSet();
        // H2 is only a cache source; it does not have an Integral dataset id/name.
        // Keep the response contract, but do not invent upstream metadata.
        dataSet.setId(null);
        dataSet.setName(null);
        dataSet.setRates(toFallbackRates(rates));

        RateEnquiryResponse fallback = new RateEnquiryResponse();
        fallback.setMarketDataSets(List.of(dataSet));
        return fallback;
    }



    /**
     * Converts database placeholder zero values to JSON nulls for the fallback
     * response. Integral uses null when a market rate is unavailable; returning
     * 0E-12 would incorrectly represent an unavailable rate as a real zero rate.
     */
    private List<RateData> toFallbackRates(List<RateData> rates) {
        return rates.stream()
                .map(this::toFallbackRate)
                .toList();
    }

    private RateData toFallbackRate(RateData source) {
        RateData target = new RateData();
        target.setStatus(source.getStatus());
        target.setRateId(source.getRateId());
        target.setTenor(source.getTenor());
        target.setCurrencyPair(source.getCurrencyPair());
        target.setBid(toNullableRate(source.getBid()));
        target.setMid(toNullableRate(source.getMid()));
        target.setOffer(toNullableRate(source.getOffer()));
        target.setBaseCurrency(source.getBaseCurrency());
        target.setTermCurrency(source.getTermCurrency());
        target.setBidLastUpdatedTime(source.getBidLastUpdatedTime());
        target.setOfferLastUpdatedTime(source.getOfferLastUpdatedTime());
        target.setMidLastUpdatedTime(source.getMidLastUpdatedTime());
        return target;
    }

    private BigDecimal toNullableRate(BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) == 0
                ? BigDecimal.ZERO.setScale(1)
                : value;
    }

    public void refreshRates() {
        log.info("Starting scheduled FX rate snapshot refresh");

        String ssoToken = loginAndGetSsoToken();

        ResponseEntity<String> response = rateEnquiryApi.fetchRates(ssoToken);

        log.info(
                "Scheduled Integral Rate Enquiry completed. httpStatus={}",
                response == null ? "NO_RESPONSE" : response.getStatusCode().value()
        );

        validateHttpResponse(response);

        RateEnquiryResponse rateResponse = parseResponse(response.getBody());
        SnapshotData snapshotData = extractSnapshotData(rateResponse);

        if (snapshotData.rates().isEmpty()) {
            log.warn(
                    "Integral Rate Enquiry returned no usable rates. "
                            + "Existing H2 snapshot will be retained."
            );
            return;
        }

        replaceSnapshot(
                snapshotData.rates(),
                snapshotData.date(),
                snapshotData.createdTime()
        );

        log.info(
                "FX rate snapshot refreshed successfully. {} rates stored in H2. "
                        + "Integral snapshot date={}, createdTime={}",
                snapshotData.rates().size(),
                snapshotData.date(),
                snapshotData.createdTime()
        );
    }

    private String loginAndGetSsoToken() {
        RateEnquiryProperties.Login login = properties.getLogin();
        require(login.getUser(), "app.rate-enquiry.login.user");
        require(login.getPass(), "app.rate-enquiry.login.pass");
        require(login.getOrg(), "app.rate-enquiry.login.org");

        LoginRequest request = new LoginRequest();
        request.setUser(login.getUser());
        request.setPass(login.getPass());
        request.setOrg(login.getOrg());

        ResponseEntity<LoginResponse> response =
                loginApi.loginForRateEnquiry(request);

        if (response == null || !response.getStatusCode().is2xxSuccessful()) {
            throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY,
                    "Integral LOGIN failed: HTTP "
                            + (response == null ? "no-response" : response.getStatusCode().value()));
        }

        String token = response.getHeaders().getFirst("SSO_TOKEN");
        if (!StringUtils.hasText(token)) {
            token = response.getHeaders().getFirst("SSO-TOKEN");
        }
        if (!StringUtils.hasText(token)) {
            throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY,
                    "Integral LOGIN succeeded but SSO_TOKEN was not returned");
        }

        log.info("Integral LOGIN succeeded for Rate Enquiry; SSO token received");
        return token;
    }

    private void validateHttpResponse(ResponseEntity<String> response) {
        if (response == null || !response.getStatusCode().is2xxSuccessful()) {
            throw new RequestQuoteException("RATE_ENQUIRY", HttpStatus.BAD_GATEWAY,
                    "Integral Rate Enquiry failed: HTTP "
                            + (response == null ? "no-response" : response.getStatusCode().value()));
        }
        if (!StringUtils.hasText(response.getBody())) {
            throw new RequestQuoteException("RATE_ENQUIRY", HttpStatus.BAD_GATEWAY,
                    "Integral Rate Enquiry returned an empty response body");
        }
    }

    private RateEnquiryResponse parseResponse(String rawResponse) {
        try {
            return objectMapper.readValue(rawResponse, RateEnquiryResponse.class);
        } catch (JsonProcessingException | IllegalArgumentException ex) {
            throw new RequestQuoteException("RATE_ENQUIRY", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Rate Enquiry response: " + ex.getMessage());
        }
    }

    /**
     * Extracts the rates and the snapshot metadata supplied by Integral.
     *
     * <p>The H2 cache must represent the Integral market-data snapshot, so
     * the date and createdTime are taken from the response rather than from
     * the scheduler execution time.</p>
     */
    private SnapshotData extractSnapshotData(RateEnquiryResponse response) {
        Map<String, RateData> ratesByCurrencyPair = new LinkedHashMap<>();

        if (response == null || response.getMarketDataSets() == null) {
            return new SnapshotData(null, null, new ArrayList<>());
        }

        String snapshotDate = null;
        String snapshotCreatedTime = null;

        for (MarketDataSet dataSet : response.getMarketDataSets()) {
            if (dataSet == null || dataSet.getRates() == null) {
                continue;
            }

            if (!StringUtils.hasText(snapshotDate)
                    && StringUtils.hasText(dataSet.getDate())) {
                snapshotDate = dataSet.getDate().trim();
            }

            if (!StringUtils.hasText(snapshotCreatedTime)
                    && StringUtils.hasText(dataSet.getCreatedTime())) {
                snapshotCreatedTime = dataSet.getCreatedTime().trim();
            }

            for (RateData rate : dataSet.getRates()) {
                if (rate != null && StringUtils.hasText(rate.getCurrencyPair())) {
                    ratesByCurrencyPair.put(
                            rate.getCurrencyPair().trim(),
                            rate
                    );
                }
            }
        }

        if (ratesByCurrencyPair.isEmpty()) {
            return new SnapshotData(snapshotDate, snapshotCreatedTime, new ArrayList<>());
        }

        if (!StringUtils.hasText(snapshotDate)
                || !StringUtils.hasText(snapshotCreatedTime)) {
            throw new RequestQuoteException(
                    "RATE_ENQUIRY",
                    HttpStatus.BAD_GATEWAY,
                    "Integral Rate Enquiry response is missing date or createdTime"
            );
        }

        return new SnapshotData(
                snapshotDate,
                snapshotCreatedTime,
                new ArrayList<>(ratesByCurrencyPair.values())
        );
    }

    private void replaceSnapshot(
            List<RateData> rates,
            String snapshotDate,
            String snapshotCreatedTime) {

        fxRateH2TransactionTemplate.executeWithoutResult(status ->
                snapshotRepository.replaceSnapshot(
                        rates,
                        snapshotDate,
                        snapshotCreatedTime
                )
        );
    }

    private record SnapshotData(
            String date,
            String createdTime,
            List<RateData> rates) {
    }

    private void require(String value, String propertyName) {
        if (!StringUtils.hasText(value)) {
            throw new RequestQuoteException("CONFIGURATION", HttpStatus.INTERNAL_SERVER_ERROR,
                    propertyName + " is not configured");
        }
    }
}
