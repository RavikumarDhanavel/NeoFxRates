package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.mashreq.obms.neofxrates.config.RequestQuoteProperties;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestQuoteRequest {
    private String clOrderId;
    private String symbol;
    private Number amount;
    private String dealtCurrency;
    private String side;
    private Boolean rfq;
    private Number expiry;
    private String priceType;
    private String customerAccount;
    private String customerOrg;
    private String nearValueDate;

    public RequestQuoteRequest buildReq(IndicativeFxRateEnquiryRequest request, String symbol, RequestQuoteProperties properties) {
        if (request == null) {
            throw new IllegalArgumentException("request cannot be null");
        }
        if (symbol == null || symbol.isBlank()) {
            throw new IllegalArgumentException("symbol cannot be null or blank");
        }

        if (properties == null) {
            throw new IllegalArgumentException("Request Quote properties are required");
        }

        RequestQuoteRequest requestQuoteRequest = new RequestQuoteRequest();
        requestQuoteRequest.setRfq(properties.isRfq());
        requestQuoteRequest.setExpiry(properties.getExpiry());
        requestQuoteRequest.setPriceType(properties.getPriceType());
        requestQuoteRequest.setCustomerAccount(properties.getCustomerAccount());
        requestQuoteRequest.setCustomerOrg(properties.getCustomerOrg());
        requestQuoteRequest.setNearValueDate(properties.getNearValueDate());
        requestQuoteRequest.setClOrderId(request.getRefNo());
        requestQuoteRequest.setSymbol(symbol);
        requestQuoteRequest.setAmount(request.getTransactionAmount());

        if ("D".equalsIgnoreCase(request.getPayByIndicator())) {
            requestQuoteRequest.setDealtCurrency(request.getDebitCurrency());
            requestQuoteRequest.setSide(properties.getSellSide());
        } else if ("T".equalsIgnoreCase(request.getPayByIndicator())) {
            requestQuoteRequest.setDealtCurrency(request.getTransferCurrency());
            requestQuoteRequest.setSide(properties.getBuySide());
        }

        return requestQuoteRequest;
    }
}
