package com.mashreq.obms.neofxrates.audit;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * Persists MS request/response audit records in the dedicated H2 database.
 */
@Repository
public class CustReqAuditRepository {

    private static final String INSERT_AUDIT_SQL = """
            INSERT INTO CUST_REQ_AUDIT (
                REQUEST_ID,API_NAME,
                HTTP_METHOD,
                REQUEST_URI,
                REQUEST_BODY,
                RESPONSE_BODY,
                HTTP_STATUS,
                REQUEST_TIME,
                RESPONSE_TIME,
                DURATION_MS,
                STATUS,
                ERROR_MESSAGE
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private final JdbcTemplate jdbcTemplate;

    public CustReqAuditRepository(
            @Qualifier("fxRateJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(CustReqAudit audit) {
        jdbcTemplate.update(
                INSERT_AUDIT_SQL,
                audit.requestId(),
                audit.apiName(),
                audit.httpMethod(),
                audit.requestUri(),
                audit.requestBody(),
                audit.responseBody(),
                audit.httpStatus(),
                audit.requestTime(),
                audit.responseTime(),
                audit.durationMs(),
                audit.status(),
                audit.errorMessage());
    }
}
