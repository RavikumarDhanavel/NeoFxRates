package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/** Runtime configuration for HTTP request/response auditing. */
@Configuration
@ConfigurationProperties(prefix = "app.audit")
@Getter
@Setter
public class AuditProperties {

    private boolean enabled = true;
    private String requestIdHeader;
    private String correlationIdHeader;
    private int requestCacheLimitBytes;
    private String maskedValue;
    private List<String> sensitiveFields = new ArrayList<>();
    private List<Endpoint> endpoints = new ArrayList<>();

    @Getter
    @Setter
    public static class Endpoint {
        private String path;
        private String method;
    }
}
