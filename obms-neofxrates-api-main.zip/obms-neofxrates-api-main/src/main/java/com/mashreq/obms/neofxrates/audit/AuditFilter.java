package com.mashreq.obms.neofxrates.audit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.obms.neofxrates.config.AuditProperties;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.UUID;

/**
 * Captures request and response details for the four MS-facing NeoFX APIs.
 *
 * <p>The filter works at the HTTP boundary, so no audit-specific code is
 * required inside the existing controllers or business services.</p>
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
@RequiredArgsConstructor
@Slf4j
public class AuditFilter extends OncePerRequestFilter {

    private final AuditService auditService;
    private final ObjectMapper objectMapper;
    private final AuditProperties properties;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        if (!properties.isEnabled()) {
            return true;
        }
        return properties.getEndpoints().stream()
                .noneMatch(endpoint -> endpoint.getPath().equals(normalizePath(request))
                        && endpoint.getMethod().equalsIgnoreCase(request.getMethod()));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request, properties.getRequestCacheLimitBytes());
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
        String requestId = resolveRequestId(request);
        response.setHeader(properties.getRequestIdHeader(), requestId);
        MDC.put("requestId", requestId);
        String requestUri = normalizePath(request);
        String apiName = requestUri.substring(requestUri.lastIndexOf('/') + 1);
        LocalDateTime requestTime = LocalDateTime.now();
        long startNanos = System.nanoTime();
        Throwable failure = null;

        try {
            filterChain.doFilter(requestWrapper, responseWrapper);

        } catch (IOException | ServletException | RuntimeException | Error ex) {

            failure = ex;
            throw ex;

        } finally {
            LocalDateTime responseTime = LocalDateTime.now();
            long durationMs = (System.nanoTime() - startNanos) / 1_000_000L;
            try {
                saveAudit(
                        requestWrapper,
                        responseWrapper,
                        requestId,
                        apiName,
                        requestUri,
                        requestTime,
                        responseTime,
                        durationMs,
                        failure
                );
            } finally {
                responseWrapper.copyBodyToResponse();
                log.info("API request completed. requestId={}, apiName={}, method={}, path={}, status={}, durationMs={}",
                        requestId, apiName, request.getMethod(), requestUri, resolveHttpStatus(responseWrapper, failure), durationMs);
                MDC.remove("requestId");
            }
        }
    }

    /**
     * Builds and persists the audit record.
     */
    private void saveAudit(
            ContentCachingRequestWrapper request,
            ContentCachingResponseWrapper response,
            String requestId,
            String apiName,
            String requestUri,
            LocalDateTime requestTime,
            LocalDateTime responseTime,
            long durationMs, Throwable failure) {

        int httpStatus = resolveHttpStatus(response, failure);

        String status = httpStatus >= 200 && httpStatus < 400 ? "SUCCESS" : "FAILED";
        String requestBody = maskSensitiveData(getBody(
                        request.getContentAsByteArray(),
                        request.getCharacterEncoding()));

        String responseBody = maskSensitiveData(
                getBody(response.getContentAsByteArray(),
                        response.getCharacterEncoding()));
        String errorMessage = failure == null ? null : failure.getMessage();
        auditService.save(new CustReqAudit(
                        requestId,
                        apiName,
                        request.getMethod(),
                        requestUri,
                        requestBody,
                        responseBody,
                        httpStatus,
                        requestTime,
                        responseTime,
                        durationMs,
                        status,
                        errorMessage
                )
        );
    }
    private int resolveHttpStatus(ContentCachingResponseWrapper response, Throwable failure) {

        int responseStatus = response.getStatus();
        if (failure == null || responseStatus >= 400) {
            return responseStatus;
        }
        if (failure instanceof RequestQuoteException exception && exception.getStatusCode() != null) {
            return exception.getStatusCode().value();
        }
        if (failure instanceof ResponseStatusException exception) {
            return exception.getStatusCode().value();
        }
        return HttpStatus.INTERNAL_SERVER_ERROR.value();
    }

    private String resolveRequestId(HttpServletRequest request) {
        String requestId = request.getHeader(properties.getRequestIdHeader());
        if (hasText(requestId)) {
            return truncateRequestId(requestId);
        }
        String correlationId = request.getHeader(properties.getCorrelationIdHeader());
        if (hasText(correlationId)) {
            return truncateRequestId(correlationId);
        }

        return UUID.randomUUID().toString();
    }

    private String truncateRequestId(String requestId) {
        return requestId.length() <= 100 ? requestId : requestId.substring(0, 100);
    }

    private String normalizePath(HttpServletRequest request) {
        String contextPath = request.getContextPath();
        String requestUri = request.getRequestURI();
        if (contextPath != null && !contextPath.isEmpty() && requestUri.startsWith(contextPath)) {
            requestUri = requestUri.substring(contextPath.length());
        }
        if (requestUri.length() > 1 && requestUri.endsWith("/")) {
            requestUri = requestUri.substring(0, requestUri.length() - 1);
        }
        return requestUri;
    }

    private String getBody(byte[] body, String characterEncoding) {
        if (body == null || body.length == 0) {
            return null;
        }
        Charset charset = characterEncoding == null ? StandardCharsets.UTF_8 : Charset.forName(characterEncoding);
        return new String(body, charset);
    }
    private String maskSensitiveData(String body) {

        if (!hasText(body)) {
            return body;
        }
        try {

            JsonNode root = objectMapper.readTree(body);
            if (root == null) {
                return body;
            }
            maskNode(root);
            return objectMapper.writeValueAsString(root);
        } catch (Exception ex) {
            return body;
        }
    }

    private void maskNode(JsonNode node) {
        if (node instanceof ObjectNode objectNode) {
            objectNode.fields().forEachRemaining(entry -> {
                if (isSensitiveField(entry.getKey())) {
                    objectNode.put(entry.getKey(), properties.getMaskedValue());
                } else {
                    maskNode(entry.getValue());
                }
            });

            return;
        }

        if (node instanceof ArrayNode arrayNode) {
            arrayNode.forEach(this::maskNode);
        }
    }
    private boolean isSensitiveField(String fieldName) {
        String normalized = fieldName.toLowerCase(Locale.ROOT);
        return properties.getSensitiveFields().stream()
                .anyMatch(field -> field.equalsIgnoreCase(normalized));
    }
    private boolean hasText(String value) {

        return value != null && !value.isBlank();
    }
}