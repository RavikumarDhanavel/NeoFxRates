package com.mashreq.obms.neofxrates.audit;

import java.time.LocalDateTime;

/**
 * Represents one MS request/response audit record stored in H2.
 */
public record CustReqAudit(
        String requestId,
        String apiName,
        String httpMethod,
        String requestUri,
        String requestBody,
        String responseBody,
        Integer httpStatus,
        LocalDateTime requestTime,
        LocalDateTime responseTime,
        long durationMs,
        String status,
        String errorMessage) {
}
