package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.time.LocalDate;


@Data
public class IndicativeFxRateEnquiryRequest {



    private String debitCurrency;
    private String transferCurrency;
    private String payByIndicator;
    private Number transactionAmount;
    private LocalDate transactionDate;
    private String cif;
    private String refNo;
    private String source;







}
