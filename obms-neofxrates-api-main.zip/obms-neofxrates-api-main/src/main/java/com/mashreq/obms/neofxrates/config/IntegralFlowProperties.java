package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/** Shared runtime settings for Integral synchronous processing windows. */
@Configuration
@ConfigurationProperties(prefix = "app.integral-flow")
@Getter
@Setter
public class IntegralFlowProperties {

    private long queryQuoteDelayMs;
    private int maxErrorResponseLength;
}
