package com.mashreq.obms.neofxrates.repository;

import com.mashreq.obms.neofxrates.dto.RateData;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Persistence adapter for the latest FX-rate snapshot in the dedicated H2 DB.
 */
@Repository
public class FxRateSnapshotRepository {

    private static final DateTimeFormatter INTEGRAL_DATE_TIME_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss,SSS Z");

    private static final String SELECT_RATES = """
            SELECT "DATE",
                   CURRENCY_PAIR,
                   BID,
                   MID,
                   OFFER,
                   BASE_CURRENCY,
                   TERM_CURRENCY,
                   CREATED_TIME
            FROM NEOFX_RATE_DATA
            """;

    private static final String INSERT_RATE_SQL = """
            INSERT INTO NEOFX_RATE_DATA (
                "DATE",
                CURRENCY_PAIR,
                BID,
                MID,
                OFFER,
                BASE_CURRENCY,
                TERM_CURRENCY,
                CREATED_TIME
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private final JdbcTemplate jdbcTemplate;

    public FxRateSnapshotRepository(
            @Qualifier("fxRateJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Returns all cached FX rates.
     */
    public List<RateData> findAllRates() {
        return jdbcTemplate.query(
                SELECT_RATES + "ORDER BY CURRENCY_PAIR",
                this::mapRateData
        );
    }

    /**
     * Returns the cached rate for the requested currency pair.
     */
    public Optional<RateData> findByCurrencyPair(String currencyPair) {
        return jdbcTemplate.query(
                        SELECT_RATES + "WHERE CURRENCY_PAIR = ?",
                        this::mapRateData,
                        currencyPair
                )
                .stream()
                .findFirst();
    }

    /**
     * Replaces the complete snapshot using the date and createdTime supplied
     * by Integral. The caller executes this operation inside the H2
     * transaction so DELETE and INSERT are committed or rolled back together.
     */
    public void replaceSnapshot(
            List<RateData> rates,
            String snapshotDate,
            String snapshotCreatedTime) {

        jdbcTemplate.update("DELETE FROM NEOFX_RATE_DATA");

        jdbcTemplate.batchUpdate(
                INSERT_RATE_SQL,
                rates,
                rates.size(),
                (statement, rate) -> {
                    statement.setDate(
                            1,
                            java.sql.Date.valueOf(snapshotDate)
                    );
                    statement.setString(
                            2,
                            rate.getCurrencyPair()
                    );
                    statement.setBigDecimal(
                            3,
                            rate.getBid()
                    );
                    statement.setBigDecimal(
                            4,
                            rate.getMid()
                    );
                    statement.setBigDecimal(
                            5,
                            rate.getOffer()
                    );
                    statement.setString(
                            6,
                            rate.getBaseCurrency()
                    );
                    statement.setString(
                            7,
                            rate.getTermCurrency()
                    );
                    statement.setTimestamp(
                            8,
                            parseIntegralCreatedTime(snapshotCreatedTime)
                    );
                }
        );
    }

    private Timestamp parseIntegralCreatedTime(String createdTime) {
        return Timestamp.from(
                OffsetDateTime.parse(
                        createdTime,
                        INTEGRAL_DATE_TIME_FORMAT
                ).toInstant()
        );
    }

    private RateData mapRateData(
            ResultSet rs,
            int rowNum) throws SQLException {

        RateData rate = new RateData();

        rate.setCurrencyPair(
                rs.getString("CURRENCY_PAIR")
        );
        rate.setBaseCurrency(
                rs.getString("BASE_CURRENCY")
        );
        rate.setTermCurrency(
                rs.getString("TERM_CURRENCY")
        );
        rate.setBid(
                rs.getBigDecimal("BID")
        );
        rate.setMid(
                rs.getBigDecimal("MID")
        );
        rate.setOffer(
                rs.getBigDecimal("OFFER")
        );

        Timestamp createdTime =
                rs.getTimestamp("CREATED_TIME");

        if (createdTime != null) {
            String timestamp =
                    createdTime.toInstant().toString();

            rate.setBidLastUpdatedTime(timestamp);
            rate.setMidLastUpdatedTime(timestamp);
            rate.setOfferLastUpdatedTime(timestamp);
        }

        return rate;
    }
}
