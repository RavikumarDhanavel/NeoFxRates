package com.mashreq.obms.neofxrates.exception;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;

import java.time.OffsetDateTime;

/** Central REST exception handler. Keeps error responses consistent across APIs. */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(RequestQuoteException.class)
    public ResponseEntity<ApiErrorResponse> handleBusinessException(
            RequestQuoteException ex, HttpServletRequest request) {
        return buildResponse(ex.getStatusCode() == null
                        ? HttpStatus.BAD_GATEWAY.value()
                        : ex.getStatusCode().value(),
                ex.getStep(), ex.getMessage(), request, ex);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiErrorResponse> handleIllegalArgument(
            IllegalArgumentException ex, HttpServletRequest request) {
        return buildResponse(HttpStatus.BAD_REQUEST.value(),
                "VALIDATION", ex.getMessage(), request, ex);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiErrorResponse> handleMalformedRequest(
            HttpMessageNotReadableException ex, HttpServletRequest request) {
        return buildResponse(HttpStatus.BAD_REQUEST.value(),
                "INVALID_REQUEST", "Request body is missing or malformed", request, ex);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiErrorResponse> handleMethodNotSupported(
            HttpRequestMethodNotSupportedException ex, HttpServletRequest request) {
        return buildResponse(HttpStatus.METHOD_NOT_ALLOWED.value(),
                "METHOD_NOT_ALLOWED", ex.getMessage(), request, ex);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> handleUnexpected(
            Exception ex, HttpServletRequest request) {
        return buildResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "INTERNAL_ERROR", "An unexpected error occurred", request, ex);
    }

    private ResponseEntity<ApiErrorResponse> buildResponse(
            int status,
            String code,
            String message,
            HttpServletRequest request,
            Exception exception) {
        HttpStatus httpStatus = HttpStatus.resolve(status);
        if (httpStatus == null) {
            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }

        String safeMessage = (message == null || message.isBlank())
                ? httpStatus.getReasonPhrase()
                : message;
        String requestId = MDC.get("requestId");

        log.error("API request failed. requestId={}, method={}, path={}, status={}, code={}",
                requestId, request.getMethod(), request.getRequestURI(),
                httpStatus.value(), code, exception);

        ApiErrorResponse response = new ApiErrorResponse(
                OffsetDateTime.now(),
                httpStatus.value(),
                httpStatus.getReasonPhrase(),
                code,
                safeMessage,
                request.getRequestURI(),
                requestId);

        return ResponseEntity.status(httpStatus).body(response);
    }
}
