package com.mashreq.obms.neofxrates.audit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Application service responsible for writing MS API audit records.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final CustReqAuditRepository auditRepository;
    public void save(CustReqAudit audit) {
        try {
            auditRepository.save(audit);
        } catch (RuntimeException ex) {
            log.error("Unable to persist MS API audit record. requestId={}, apiName={}", audit.requestId(), audit.apiName(), ex);
        }
    }
}
