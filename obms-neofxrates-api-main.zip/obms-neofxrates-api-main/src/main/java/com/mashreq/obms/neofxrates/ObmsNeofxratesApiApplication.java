package com.mashreq.obms.neofxrates;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@OpenAPIDefinition(info = @Info(
        title = "Neo FX Rates API",
        version = "v1",
        description = "FX rate enquiry, deal booking, direct-deal and cached-rate APIs"
))
@SpringBootApplication
@EnableScheduling
public class ObmsNeofxratesApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ObmsNeofxratesApiApplication.class, args);
    }
}
