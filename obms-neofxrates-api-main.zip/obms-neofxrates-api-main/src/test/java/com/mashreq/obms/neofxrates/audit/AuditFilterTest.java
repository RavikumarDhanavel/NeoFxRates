package com.mashreq.obms.neofxrates.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.AuditProperties;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class AuditFilterTest {

    @Test
    void auditsAllFourMsApis() throws Exception {
        AuditService auditService = mock(AuditService.class);
        AuditFilter filter = new AuditFilter(auditService, new ObjectMapper(), auditProperties());

        List<String> paths = List.of(
                "/neoFx/indicativeFxRateEnquiry",
                "/neoFx/dealBooking",
                "/neoFx/rateExchange",
                "/neoFx/directDeal");

        for (String path : paths) {
            String method = "/neoFx/rateExchange".equals(path) ? "GET" : "POST";
            MockHttpServletRequest request = request(path, method, "{\"source\":\"OBDX\"}");
            MockHttpServletResponse response = new MockHttpServletResponse();

            filter.doFilter(request, response, (req, res) -> {
                req.getInputStream().readAllBytes();
                res.getWriter().write("{\"status\":\"OK\"}");
            });
        }

        ArgumentCaptor<CustReqAudit> captor = ArgumentCaptor.forClass(CustReqAudit.class);
        verify(auditService, times(4)).save(captor.capture());

        List<CustReqAudit> audits = captor.getAllValues();
        assertEquals(paths, audits.stream().map(CustReqAudit::requestUri).toList());
        assertTrue(audits.stream().allMatch(audit -> "SUCCESS".equals(audit.status())));
        assertTrue(audits.stream().allMatch(audit -> audit.httpStatus() == 200));
        assertTrue(audits.stream().allMatch(audit -> audit.responseBody().contains("OK")));
    }

    @Test
    void masksSensitiveValuesBeforePersistingAudit() throws Exception {
        AuditService auditService = mock(AuditService.class);
        AuditFilter filter = new AuditFilter(auditService, new ObjectMapper(), auditProperties());

        MockHttpServletRequest request = request(
                "/neoFx/directDeal",
                "POST",
                "{\"user\":\"prov\",\"pass\":\"secret-value\",\"token\":\"token-value\"}");
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, (req, res) -> {
            req.getInputStream().readAllBytes();
            res.getWriter().write("{\"SSO_TOKEN\":\"response-token\",\"status\":\"OK\"}");
        });

        ArgumentCaptor<CustReqAudit> captor = ArgumentCaptor.forClass(CustReqAudit.class);
        verify(auditService).save(captor.capture());

        CustReqAudit audit = captor.getValue();
        assertTrue(audit.requestBody().contains("[MASKED]"));
        assertFalse(audit.requestBody().contains("secret-value"));
        assertFalse(audit.requestBody().contains("token-value"));
        assertFalse(audit.responseBody().contains("response-token"));
        assertTrue(audit.responseBody().contains("[MASKED]"));
    }

    private AuditProperties auditProperties() {
        AuditProperties properties = new AuditProperties();
        properties.setEnabled(true);
        properties.setRequestIdHeader("X-Request-ID");
        properties.setCorrelationIdHeader("X-Correlation-ID");
        properties.setRequestCacheLimitBytes(1024 * 1024);
        properties.setMaskedValue("[MASKED]");
        properties.setSensitiveFields(List.of("pass", "password", "authorization", "token", "sso_token", "sso-token", "secret", "hmac"));
        for (String path : List.of("/neoFx/indicativeFxRateEnquiry", "/neoFx/dealBooking", "/neoFx/rateExchange", "/neoFx/directDeal")) {
            AuditProperties.Endpoint endpoint = new AuditProperties.Endpoint();
            endpoint.setPath(path);
            endpoint.setMethod("/neoFx/rateExchange".equals(path) ? "GET" : "POST");
            properties.getEndpoints().add(endpoint);
        }
        return properties;
    }

    private MockHttpServletRequest request(String path, String method, String body) {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI(path);
        request.setMethod(method);
        request.setCharacterEncoding(StandardCharsets.UTF_8.name());
        request.setContent(body.getBytes(StandardCharsets.UTF_8));
        return request;
    }
}
