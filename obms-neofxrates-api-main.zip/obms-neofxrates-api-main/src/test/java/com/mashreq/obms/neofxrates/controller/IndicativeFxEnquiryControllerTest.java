package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndicativeFxEnquiryControllerTest {

    @Mock
    private IndicativeFxRateService service;

    @InjectMocks
    private NeoFxController controller;

    @Test
    void indicativeFxRateEnquiry_delegatesToServiceAndReturnsResponse() {
        IndicativeFxRateEnquiryRequest request =
                new IndicativeFxRateEnquiryRequest();

        IndicativeFxRateEnquiryResponse response =
                new IndicativeFxRateEnquiryResponse();

        ResponseEntity<IndicativeFxRateEnquiryResponse> expected =
                ResponseEntity.ok(response);

        when(service.fetchFxRate(request)).thenReturn(expected);

        ResponseEntity<IndicativeFxRateEnquiryResponse> actual =
                controller.indicativeFxRateEnquiry(request);

        assertSame(expected, actual);
        verify(service, times(1)).fetchFxRate(request);
    }

    @Test
    void indicativeFxRateEnquiry_propagatesServiceException() {
        IndicativeFxRateEnquiryRequest request =
                new IndicativeFxRateEnquiryRequest();

        RuntimeException exception =
                new RuntimeException("failure");

        when(service.fetchFxRate(request)).thenThrow(exception);

        RuntimeException actual = assertThrows(
                RuntimeException.class,
                () -> controller.indicativeFxRateEnquiry(request)
        );

        assertSame(exception, actual);
        verify(service, times(1)).fetchFxRate(request);
    }
}