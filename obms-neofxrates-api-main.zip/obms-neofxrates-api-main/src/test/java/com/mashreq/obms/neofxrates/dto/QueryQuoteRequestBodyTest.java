package com.mashreq.obms.neofxrates.dto;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class QueryQuoteRequestBodyTest {

    @Test
    void from_copiesRequestFields() {
        IndicativeFxRateEnquiryRequest request =
                new IndicativeFxRateEnquiryRequest();
        request.setDebitCurrency("AED");
        request.setTransferCurrency("USD");
        request.setPayByIndicator("D");
        request.setTransactionDate(LocalDate.of(2026, 9, 29));
        request.setCif("CIF-1");
        request.setRefNo("REF-1");
        request.setSource("OBDX");

        QueryQuoteRequestBody body = QueryQuoteRequestBody.from(request);

        assertEquals("AED", body.getDebitCurrency());
        assertEquals("USD", body.getTransferCurrency());
        assertEquals("D", body.getPayByIndicator());
        assertEquals(LocalDate.of(2026, 9, 29), body.getTransactionDate());
        assertEquals("CIF-1", body.getCif());
        assertEquals("REF-1", body.getRefNo());
        assertEquals("OBDX", body.getSource());
    }
}
