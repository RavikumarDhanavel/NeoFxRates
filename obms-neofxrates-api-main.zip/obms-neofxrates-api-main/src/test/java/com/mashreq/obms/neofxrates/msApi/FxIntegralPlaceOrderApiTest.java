package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralPlaceOrderApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private EndpointsConfig endpointsConfig;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FxIntegralPlaceOrderApi api;

    @Test
    void placeOrder_usesNormalAuthenticationHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getPlaceOrder()).thenReturn("/v2/orders");

        DirectDealPlaceOrderRequest request = DirectDealPlaceOrderRequest.builder().build();
        ResponseEntity<String> expected = ResponseEntity.ok("{}");

        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(expected);

        ResponseEntity<String> actual = api.placeOrder(request);

        assertSame(expected, actual);
        ArgumentCaptor<String> url = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).exchange(
                url.capture(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertEquals("https://integral.example/v2/orders", url.getValue());
        assertSame(request, entity.getValue().getBody());
        assertEquals("application/json",
                entity.getValue().getHeaders().getFirst("Content-Type"));
        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
    }

    @Test
    void placeOrderWithSso_addsSsoAndSkipHmacHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getPlaceOrder()).thenReturn("/v2/orders");

        DirectDealPlaceOrderRequest request = DirectDealPlaceOrderRequest.builder().build();
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.placeOrderWithSso(request, "sso-token");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertEquals("sso-token",
                entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertEquals("true",
                entity.getValue().getHeaders()
                        .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }

    @Test
    void placeOrderWithBlankSso_keepsNormalAuthentication() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getPlaceOrder()).thenReturn("/v2/orders");
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.placeOrderWithSso(DirectDealPlaceOrderRequest.builder().build(), " ");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertNull(entity.getValue().getHeaders()
                .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }
}
