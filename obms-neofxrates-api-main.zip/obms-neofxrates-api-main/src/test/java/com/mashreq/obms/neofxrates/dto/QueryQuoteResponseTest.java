package com.mashreq.obms.neofxrates.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class QueryQuoteResponseTest {

    @Test
    void canCreateResponseDto() {
        assertNotNull(new QueryQuoteResponse());
    }
}
