package com.mashreq.obms.neofxrates.scheduler;

import com.mashreq.obms.neofxrates.service.FxRateEnquiryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class FxRateSchedulerTest {

    @Mock
    private FxRateEnquiryService fxRateEnquiryService;

    @InjectMocks
    private FxRateScheduler scheduler;

    @Test
    void fetchRates_refreshesRatesSuccessfully() {
        scheduler.fetchRates();

        verify(fxRateEnquiryService).refreshRates();
    }

    @Test
    void fetchRates_handlesRefreshFailureAndDoesNotPropagate() {
        doThrow(new RuntimeException("H2 unavailable"))
                .when(fxRateEnquiryService)
                .refreshRates();

        assertDoesNotThrow(() -> scheduler.fetchRates());

        verify(fxRateEnquiryService).refreshRates();
    }
}
