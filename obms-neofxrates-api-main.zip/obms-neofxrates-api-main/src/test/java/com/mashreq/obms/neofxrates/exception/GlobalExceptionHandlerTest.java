package com.mashreq.obms.neofxrates.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    @Mock
    private HttpServletRequest request;

    private GlobalExceptionHandler handler;

    @BeforeEach
    void setUp() {
        handler = new GlobalExceptionHandler();
        when(request.getMethod()).thenReturn("POST");
        when(request.getRequestURI()).thenReturn("/api/fx/rate");
    }

    @Test
    void handleBusinessException_usesExceptionStatusAndStep() {
        RequestQuoteException exception =
                new RequestQuoteException(
                        "QUERY_QUOTE",
                        HttpStatus.BAD_GATEWAY,
                        "Integral unavailable");

        ResponseEntity<ApiErrorResponse> response =
                handler.handleBusinessException(exception, request);

        assertEquals(HttpStatus.BAD_GATEWAY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("QUERY_QUOTE", response.getBody().code());
        assertEquals("Integral unavailable", response.getBody().message());
    }

    @Test
    void handleBusinessException_defaultsNullStatusToBadGateway() {
        RequestQuoteException exception =
                new RequestQuoteException(
                        "QUERY_QUOTE",
                        null,
                        "Integral unavailable");

        ResponseEntity<ApiErrorResponse> response =
                handler.handleBusinessException(exception, request);

        assertEquals(HttpStatus.BAD_GATEWAY, response.getStatusCode());
    }

    @Test
    void handleIllegalArgument_returnsBadRequest() {
        ResponseEntity<ApiErrorResponse> response =
                handler.handleIllegalArgument(
                        new IllegalArgumentException("invalid field"),
                        request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("VALIDATION", response.getBody().code());
        assertEquals("invalid field", response.getBody().message());
    }

    @Test
    void handleMalformedRequest_returnsBadRequest() {
        HttpMessageNotReadableException exception =
                new HttpMessageNotReadableException("malformed", (HttpInputMessage) null);

        ResponseEntity<ApiErrorResponse> response =
                handler.handleMalformedRequest(exception, request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("INVALID_REQUEST", response.getBody().code());
        assertEquals("Request body is missing or malformed",
                response.getBody().message());
    }

    @Test
    void handleMethodNotSupported_returnsMethodNotAllowed() {
        HttpRequestMethodNotSupportedException exception =
                new HttpRequestMethodNotSupportedException("POST");

        ResponseEntity<ApiErrorResponse> response =
                handler.handleMethodNotSupported(exception, request);

        assertEquals(HttpStatus.METHOD_NOT_ALLOWED, response.getStatusCode());
        assertEquals("METHOD_NOT_ALLOWED", response.getBody().code());
    }

    @Test
    void handleUnexpected_returnsInternalServerError() {
        ResponseEntity<ApiErrorResponse> response =
                handler.handleUnexpected(
                        new RuntimeException("unexpected"),
                        request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("INTERNAL_ERROR", response.getBody().code());
        assertEquals("An unexpected error occurred",
                response.getBody().message());
    }
}
