package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.IndicativeFxProperties;
import com.mashreq.obms.neofxrates.config.IntegralFlowProperties;
import com.mashreq.obms.neofxrates.config.RequestQuoteProperties;
import com.mashreq.obms.neofxrates.dto.*;
import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRequestQuoteApi;
import com.mashreq.obms.neofxrates.repository.FxRateSnapshotRepository;
import com.mashreq.obms.neofxrates.repository.TraditionalCurrencyPairDirectionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IndicativeFxRateServiceTest {

    @Mock
    FxIntegralRequestQuoteApi requestQuoteApi;

    @Mock
    FxIntegralQueryQuoteApi queryQuoteApi;

    @Mock
    TraditionalCurrencyPairDirectionRepository currencyPairRepository;

    @Mock
    FxRateSnapshotRepository fxRateSnapshotRepository;

    @Spy
    ObjectMapper objectMapper = new ObjectMapper();

    @Spy
    IntegralFlowProperties integralFlowProperties = flowProperties();

    @Spy
    RequestQuoteProperties requestQuoteProperties = requestQuoteProperties();

    @Spy
    IndicativeFxProperties indicativeFxProperties = indicativeFxProperties();

    @InjectMocks
    IndicativeFxRateService service;

    private static IntegralFlowProperties flowProperties() {
        IntegralFlowProperties properties = new IntegralFlowProperties();
        properties.setQueryQuoteDelayMs(0);
        properties.setMaxErrorResponseLength(2000);
        return properties;
    }

    private static RequestQuoteProperties requestQuoteProperties() {
        RequestQuoteProperties properties = new RequestQuoteProperties();
        properties.setRfq(true);
        properties.setExpiry(120);
        properties.setPriceType("Spot");
        properties.setCustomerAccount("NEOFX_UAE_CIBG_Regular");
        properties.setCustomerOrg("NEOFX_UAE_CIBG_Regular");
        properties.setNearValueDate("SPOT");
        properties.setSellSide("SELL");
        properties.setBuySide("BUY");
        return properties;
    }

    private static IndicativeFxProperties indicativeFxProperties() {
        IndicativeFxProperties properties = new IndicativeFxProperties();
        properties.setFallbackEnabled(true);
        properties.setFallbackSources(List.of("OBDX"));
        properties.setFallbackProvider("NEOFX");
        properties.setFallbackForwardPoint(new BigDecimal("0.0"));
        properties.setFallbackEffectiveTime(0);
        properties.setFallbackQuoteStatus("A");
        return properties;
    }

    @BeforeEach
    void mockCurrencyPair() {
        TraditionalCurrencyPairDirection pair =
                new TraditionalCurrencyPairDirection(1L, "USD", "AED");

        lenient()
                .when(currencyPairRepository
                        .findByBaseCurrencyAndQuoteCurrency("AED", "USD"))
                .thenReturn(Optional.empty());

        lenient()
                .when(currencyPairRepository
                        .findByBaseCurrencyAndQuoteCurrency("USD", "AED"))
                .thenReturn(Optional.of(pair));
    }

    @Test
    void successfulIntegralQuote_returnsNonCachedResponse() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-1", "CL-1", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-1"))
                .thenReturn(ResponseEntity.ok(successfulQuoteJson("3.67", "1000")));

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(validRequest());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("N", response.getBody().getData().get("cachedRate"));
        assertEquals("QUOTE", response.getBody().getData().get("event"));
        assertEquals("Y", response.getBody().getData().get("inverse"));
        assertNotNull(response.getBody().getData().get("reciprocalRate"));
        verify(requestQuoteApi).requestQuote(any());
        verify(queryQuoteApi).queryByClientId("CL-1");
        verifyNoInteractions(fxRateSnapshotRepository);
    }

    @Test
    void successfulIntegralQuote_forTransferPayBy_usesBuySide() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setPayByIndicator("T");

        when(requestQuoteApi.requestQuote(any()))
                .thenAnswer(invocation -> {
                    RequestQuoteRequest quoteRequest = invocation.getArgument(0);
                    assertEquals("USD", quoteRequest.getDealtCurrency());
                    assertEquals("BUY", quoteRequest.getSide());
                    return ResponseEntity.status(HttpStatus.ACCEPTED)
                            .body(requestQuoteResponse("REQ-2", "CL-2", "REQUEST_ACCEPTED"));
                });
        when(queryQuoteApi.queryByClientId("CL-2"))
                .thenReturn(ResponseEntity.ok(successfulQuoteJson("3.67", "1000")));

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("N", response.getBody().getData().get("inverse"));
    }

    @Test
    void missingRefNo_generatesReferenceAndContinuesFlow() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setRefNo(" ");

        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-3", "CL-3", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-3"))
                .thenReturn(ResponseEntity.ok(successfulQuoteJson("3.67", "1000")));

        service.fetchFxRate(request);

        assertTrue(request.getRefNo().startsWith("RFQ_"));
    }

    @Test
    void requestQuoteNullResponse_forObdx_usesH2Fallback() {
        when(requestQuoteApi.requestQuote(any())).thenReturn(null);
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(cachedRate("3.65", "3.66", "3.67")));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Y", response.getBody().getData().get("cachedRate"));
        verify(fxRateSnapshotRepository).findByCurrencyPair("USD/AED");
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void requestQuoteNonAcceptedResponse_forNonFallbackSource_throws() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                        .body(requestQuoteResponse("REQ-4", "CL-4", "FAILED")));

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", exception.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, exception.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void requestQuoteMissingRequestId_forObdx_usesH2Fallback() {
        RequestQuoteResponse body = new RequestQuoteResponse();
        body.setClOrderId("CL-5");
        body.setEvent("REQUEST_ACCEPTED");

        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(body));
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(cachedRate("3.65", "3.66", "3.67")));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals("Y", response.getBody().getData().get("cachedRate"));
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void queryQuoteNullResponse_forObdx_usesH2Fallback() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-6", "CL-6", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-6")).thenReturn(null);
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(cachedRate("3.65", "3.66", "3.67")));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals("Y", response.getBody().getData().get("cachedRate"));
    }

    @Test
    void queryQuoteNon2xx_forNonFallbackSource_throws() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-7", "CL-7", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-7"))
                .thenReturn(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                        .body("unavailable"));

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", exception.getStep());
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, exception.getStatusCode());
    }

    @Test
    void queryQuoteBlankBody_forObdx_usesH2Fallback() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-8", "CL-8", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-8"))
                .thenReturn(ResponseEntity.ok("   "));
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(cachedRate("3.65", "3.66", "3.67")));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals("Y", response.getBody().getData().get("cachedRate"));
    }

    @Test
    void malformedQueryQuote_forNonFallbackSource_throwsBadGateway() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-9", "CL-9", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-9"))
                .thenReturn(ResponseEntity.ok("{invalid-json"));

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", exception.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, exception.getStatusCode());
    }

    @Test
    void nonQuoteIntegralResponse_forObdx_usesH2Fallback() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-10", "CL-10", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-10"))
                .thenReturn(ResponseEntity.ok("""
                        {"data":{"event":"REQUEST_ACCEPTED","quotes":[]}}
                        """));
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(cachedRate("3.65", "3.66", "3.67")));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(request);

        assertEquals("Y", response.getBody().getData().get("cachedRate"));
    }

    @Test
    void nonQuoteIntegralResponse_forNonFallbackSource_returnsIntegralResponse() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-11", "CL-11", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-11"))
                .thenReturn(ResponseEntity.ok("""
                        {"data":{"event":"REQUEST_ACCEPTED","quotes":[]}}
                        """));

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(validRequest());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("N", response.getBody().getData().get("cachedRate"));
        assertEquals("REQUEST_ACCEPTED", response.getBody().getData().get("event"));
    }

    @Test
    void obpayDoesNotUseH2FallbackWhenIntegralFails() {
        when(requestQuoteApi.requestQuote(any()))
                .thenThrow(new RequestQuoteException(
                        "REQUEST_QUOTE", HttpStatus.BAD_GATEWAY, "Integral unavailable"));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBPAY");

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("REQUEST_QUOTE", exception.getStep());
        verifyNoInteractions(fxRateSnapshotRepository);
    }

    @Test
    void obdxFallbackWithNoCachedRate_returnsBadGateway() {
        when(requestQuoteApi.requestQuote(any()))
                .thenThrow(new RequestQuoteException(
                        "REQUEST_QUOTE", HttpStatus.BAD_GATEWAY, "Integral unavailable"));
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.empty());

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("H2_FALLBACK", exception.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, exception.getStatusCode());
    }

    @Test
    void obdxFallbackWithInvalidSelectedRate_returnsBadGateway() {
        when(requestQuoteApi.requestQuote(any()))
                .thenThrow(new RequestQuoteException(
                        "REQUEST_QUOTE", HttpStatus.BAD_GATEWAY, "Integral unavailable"));

        RateData rate = cachedRate("3.65", "3.66", null);
        when(fxRateSnapshotRepository.findByCurrencyPair("USD/AED"))
                .thenReturn(Optional.of(rate));

        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setSource("OBDX");

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("H2_FALLBACK", exception.getStep());
        assertTrue(exception.getMessage().contains("missing or invalid"));
    }

    @Test
    void invalidPayByIndicator_isRejectedBeforeExternalCalls() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setPayByIndicator("X");

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("VALIDATION", exception.getStep());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        verifyNoInteractions(requestQuoteApi, queryQuoteApi);
    }

    @Test
    void missingTransactionAmount_isRejectedBeforeExternalCalls() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setTransactionAmount(null);

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("VALIDATION", exception.getStep());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
    }

    @Test
    void missingCurrencyPair_isRejected() {
        when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("AED", "USD"))
                .thenReturn(Optional.empty());
        when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("USD", "AED"))
                .thenReturn(Optional.empty());

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(validRequest()));

        assertEquals("CURRENCY_PAIR", exception.getStep());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
    }

    @Test
    void queryQuoteWithZeroRate_isRejected() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-12", "CL-12", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-12"))
                .thenReturn(ResponseEntity.ok(successfulQuoteJson("0", "1000")));

        RequestQuoteException exception = assertThrows(
                RequestQuoteException.class,
                () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", exception.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, exception.getStatusCode());
    }

    @Test
    void queryQuoteWithBidsAndNoDealtAmount_keepsSettledAmountAbsent() {
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body(requestQuoteResponse("REQ-13", "CL-13", "REQUEST_ACCEPTED")));
        when(queryQuoteApi.queryByClientId("CL-13"))
                .thenReturn(ResponseEntity.ok("""
                        {"data":{"event":"QUOTE","quotes":[
                          {"bids":[{"rate":3.65}]}
                        ]}}
                        """));

        ResponseEntity<IndicativeFxRateEnquiryResponse> response =
                service.fetchFxRate(validRequest());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("N", response.getBody().getData().get("cachedRate"));
        assertNotNull(response.getBody().getData().get("quotes"));
    }

    private IndicativeFxRateEnquiryRequest validRequest() {
        IndicativeFxRateEnquiryRequest request =
                new IndicativeFxRateEnquiryRequest();
        request.setDebitCurrency("AED");
        request.setTransferCurrency("USD");
        request.setPayByIndicator("D");
        request.setTransactionAmount(1000);
        request.setRefNo("RFQ-123");
        return request;
    }

    private RequestQuoteResponse requestQuoteResponse(
            String requestId, String clOrderId, String event) {
        RequestQuoteResponse response = new RequestQuoteResponse();
        response.setRequestId(requestId);
        response.setClOrderId(clOrderId);
        response.setEvent(event);
        response.setStatus("A");
        return response;
    }

    private String successfulQuoteJson(String rate, String dealtAmount) {
        return """
                {
                  "data": {
                    "event": "QUOTE",
                    "quotes": [
                      {
                        "symbol": "USD/AED",
                        "dealtCurrency": "AED",
                        "offers": [
                          {
                            "type": "OFFER",
                            "rate": %s,
                            "dealtAmount": %s
                          }
                        ]
                      }
                    ]
                  }
                }
                """.formatted(rate, dealtAmount);
    }

    private RateData cachedRate(
            String bid, String mid, String offer) {
        RateData rate = new RateData();
        rate.setCurrencyPair("USD/AED");
        rate.setBaseCurrency("USD");
        rate.setTermCurrency("AED");
        rate.setBid(toDecimal(bid));
        rate.setMid(toDecimal(mid));
        rate.setOffer(toDecimal(offer));
        return rate;
    }

    private BigDecimal toDecimal(String value) {
        return value == null ? null : new BigDecimal(value);
    }
}
