package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.RateEnquiryProperties;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.dto.RateData;
import com.mashreq.obms.neofxrates.dto.RateEnquiryResponse;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRateEnquiryApi;
import com.mashreq.obms.neofxrates.repository.FxRateSnapshotRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxRateEnquiryServiceTest {

    @Mock
    private FxIntegralLoginApi loginApi;

    @Mock
    private FxIntegralRateEnquiryApi rateEnquiryApi;

    @Mock
    private FxRateSnapshotRepository snapshotRepository;

    @Mock
    private TransactionTemplate transactionTemplate;

    private FxRateEnquiryService service;

    @BeforeEach
    void setUp() {
        RateEnquiryProperties properties = new RateEnquiryProperties();
        RateEnquiryProperties.Login login = new RateEnquiryProperties.Login();
        login.setUser("prov");
        login.setPass("secret");
        login.setOrg("NEOFX");
        properties.setLogin(login);

        service = new FxRateEnquiryService(
                loginApi,
                rateEnquiryApi,
                snapshotRepository,
                properties,
                new ObjectMapper(),
                transactionTemplate);

        lenient().doAnswer(invocation -> {
            Consumer<org.springframework.transaction.TransactionStatus> action = invocation.getArgument(0);
            action.accept(null);
            return null;
        }).when(transactionTemplate).executeWithoutResult(any());
    }

    @Test
    void successfulResponseReplacesSnapshot() {
        when(loginApi.loginForRateEnquiry(any()))
                .thenReturn(loginResponse("new-token"));
        when(rateEnquiryApi.fetchRates("new-token"))
                .thenReturn(ResponseEntity.ok("""
                        {"marketDataSets":[{"date":"2026-09-29","createdTime":"2026-09-29 23:23:00,000 +0000","rates":[
                          {"currencyPair":"USD/AED","baseCurrency":"USD","termCurrency":"AED","bid":3.65,"mid":3.67,"offer":3.69}
                        ]}]}\n"""));

        service.refreshRates();

        ArgumentCaptor<List<RateData>> captor = ArgumentCaptor.forClass(List.class);
        verify(snapshotRepository).replaceSnapshot(captor.capture(), any(), any());
        assertEquals(1, captor.getValue().size());
        assertEquals("USD/AED", captor.getValue().get(0).getCurrencyPair());

        ArgumentCaptor<String> dateCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> createdTimeCaptor = ArgumentCaptor.forClass(String.class);

        verify(snapshotRepository).replaceSnapshot(
                any(),
                dateCaptor.capture(),
                createdTimeCaptor.capture()
        );

        assertEquals("2026-09-29", dateCaptor.getValue());
        assertEquals(
                "2026-09-29 23:23:00,000 +0000",
                createdTimeCaptor.getValue()
        );
    }

    @Test
    void emptyRatesRetainExistingSnapshot() {
        when(loginApi.loginForRateEnquiry(any()))
                .thenReturn(loginResponse("new-token"));
        when(rateEnquiryApi.fetchRates("new-token"))
                .thenReturn(ResponseEntity.ok("{\"marketDataSets\":[{\"rates\":[]}] }"));

        service.refreshRates();

        verify(snapshotRepository, never()).replaceSnapshot(any(), any(), any());
    }

    @Test
    void missingMarketDataSetsRetainExistingSnapshot() {
        when(loginApi.loginForRateEnquiry(any()))
                .thenReturn(loginResponse("new-token"));
        when(rateEnquiryApi.fetchRates("new-token"))
                .thenReturn(ResponseEntity.ok("{}"));

        service.refreshRates();

        verify(snapshotRepository, never()).replaceSnapshot(any(), any(), any());
    }

    @Test
    void loginFailureDoesNotTouchSnapshot() {
        when(loginApi.loginForRateEnquiry(any()))
                .thenThrow(new IllegalStateException("login failed"));

        assertThrows(
                IllegalStateException.class,
                () -> service.refreshRates()
        );

        verify(snapshotRepository, never())
                .replaceSnapshot(any(), any(), any());
    }

    @Test
    void nonSuccessfulRateEnquiryDoesNotTouchSnapshot() {
        when(loginApi.loginForRateEnquiry(any()))
                .thenReturn(loginResponse("new-token"));

        when(rateEnquiryApi.fetchRates("new-token"))
                .thenReturn(ResponseEntity.status(503).body("service unavailable")
                );

        assertThrows(
                RequestQuoteException.class, () -> service.refreshRates()
        );

        verify(snapshotRepository, never())
                .replaceSnapshot(any(), any(), any());
    }


    @Test
    void fallbackPreservesExistingZeroRateRepresentationAndDoesNotInventH2DatasetId() {
        RateData rate = new RateData();
        rate.setCurrencyPair("AED/OMR");
        rate.setBaseCurrency("AED");
        rate.setTermCurrency("OMR");
        rate.setBid(new java.math.BigDecimal("0.000000000000"));
        rate.setMid(new java.math.BigDecimal("0.000000000000"));
        rate.setOffer(new java.math.BigDecimal("0.000000000000"));
        rate.setBidLastUpdatedTime("2026-09-28T09:23:00.896486Z");
        rate.setMidLastUpdatedTime("2026-09-28T09:23:00.896486Z");
        rate.setOfferLastUpdatedTime("2026-09-28T09:23:00.896486Z");

        when(loginApi.loginForRateEnquiry(any()))
                .thenThrow(new IllegalStateException("Integral unavailable"));
        when(snapshotRepository.findAllRates()).thenReturn(List.of(rate));

        RateEnquiryResponse response = service.fetchRatesWithFallback();

        assertEquals(1, response.getMarketDataSets().size());
        assertNull(response.getMarketDataSets().get(0).getId());
        assertNull(response.getMarketDataSets().get(0).getName());
        RateData fallbackRate = response.getMarketDataSets().get(0).getRates().get(0);
        assertEquals(new java.math.BigDecimal("0.0"), fallbackRate.getBid());
        assertEquals(new java.math.BigDecimal("0.0"), fallbackRate.getMid());
        assertEquals(new java.math.BigDecimal("0.0"), fallbackRate.getOffer());
    }

    private ResponseEntity<LoginResponse> loginResponse(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("SSO_TOKEN", token);
        return ResponseEntity.ok().headers(headers).body(new LoginResponse());
    }
}
