package com.mashreq.obms.neofxrates.exception;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ApiErrorResponseTest {

    @Test
    void recordStoresAllErrorFields() {
        OffsetDateTime timestamp = OffsetDateTime.now();

        ApiErrorResponse response = new ApiErrorResponse(
                timestamp,
                400,
                "Bad Request",
                "VALIDATION",
                "Invalid request",
                "/api/fx/rate",
                "REQ-1");

        assertEquals(timestamp, response.timestamp());
        assertEquals(400, response.status());
        assertEquals("Bad Request", response.error());
        assertEquals("VALIDATION", response.code());
        assertEquals("Invalid request", response.message());
        assertEquals("/api/fx/rate", response.path());
        assertEquals("REQ-1", response.requestId());
    }
}
