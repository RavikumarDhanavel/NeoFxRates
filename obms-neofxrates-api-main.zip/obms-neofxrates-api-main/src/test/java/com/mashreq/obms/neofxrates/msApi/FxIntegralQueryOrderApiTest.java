package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralQueryOrderApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private EndpointsConfig endpointsConfig;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FxIntegralQueryOrderApi api;

    @Test
    void queryOrder_buildsExpectedGetRequest() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getQueryOrder()).thenReturn("/v2/orders/");

        ResponseEntity<String> expected = ResponseEntity.ok("{}");
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(expected);

        assertSame(expected, api.queryOrder("ORDER-1"));

        ArgumentCaptor<String> url = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).exchange(
                url.capture(), eq(HttpMethod.GET), entity.capture(), eq(String.class));

        assertEquals("https://integral.example/v2/orders/ORDER-1", url.getValue());
        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
    }

    @Test
    void queryOrderWithSso_setsSsoAndSkipHmacHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getQueryOrder()).thenReturn("/v2/orders/");
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.queryOrderWithSso("ORDER-2", "sso-token");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.GET), entity.capture(), eq(String.class));

        assertEquals("sso-token",
                entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertEquals("true",
                entity.getValue().getHeaders()
                        .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }

    @Test
    void queryOrderWithBlankSso_doesNotSetSsoHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getQueryOrder()).thenReturn("/v2/orders/");
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.queryOrderWithSso("ORDER-3", " ");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.GET), entity.capture(), eq(String.class));

        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertNull(entity.getValue().getHeaders()
                .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }
}
