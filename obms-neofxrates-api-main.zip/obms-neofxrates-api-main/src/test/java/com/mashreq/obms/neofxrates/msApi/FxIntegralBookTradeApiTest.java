package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.DirectDealBookTradeRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralBookTradeApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private EndpointsConfig endpointsConfig;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FxIntegralBookTradeApi api;

    @Test
    void bookTrade_usesPostEndpoint() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getBookTrade()).thenReturn("/v2/book-trade");

        DirectDealBookTradeRequest request = DirectDealBookTradeRequest.builder().build();
        ResponseEntity<String> expected = ResponseEntity.ok("{}");

        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(expected);

        assertSame(expected, api.bookTrade(request));

        ArgumentCaptor<String> url = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).exchange(
                url.capture(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertEquals("https://integral.example/v2/book-trade", url.getValue());
        assertSame(request, entity.getValue().getBody());
        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
    }

    @Test
    void bookTradeWithSso_addsSsoAndSkipHmacHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getBookTrade()).thenReturn("/v2/book-trade");

        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.bookTradeWithSso(DirectDealBookTradeRequest.builder().build(), "sso-token");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertEquals("sso-token",
                entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertEquals("true",
                entity.getValue().getHeaders()
                        .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }

    @Test
    void bookTradeWithBlankSso_doesNotSetSsoHeaders() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getBookTrade()).thenReturn("/v2/book-trade");
        when(restTemplate.exchange(
                anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok("{}"));

        api.bookTradeWithSso(DirectDealBookTradeRequest.builder().build(), "");

        ArgumentCaptor<HttpEntity> entity = ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).exchange(
                anyString(), eq(HttpMethod.POST), entity.capture(), eq(String.class));

        assertNull(entity.getValue().getHeaders().getFirst("SSO_TOKEN"));
        assertNull(entity.getValue().getHeaders()
                .getFirst(IntegralHmacInterceptor.SKIP_HMAC_HEADER));
    }
}
