package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralLoginApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private EndpointsConfig endpointsConfig;

    @Mock
    private RestTemplate restTemplate;

    @Test
    void login_callsExistingHmacRestTemplate() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getSsoLogin()).thenReturn("/v2/sso/login");

        FxIntegralLoginApi api = new FxIntegralLoginApi(
                applicationConfig,
                endpointsConfig,
                restTemplate);

        LoginRequest request = new LoginRequest();
        request.setUser("u");
        request.setPass("p");
        request.setOrg("o");

        LoginResponse body = new LoginResponse();
        body.setStatus("OK");
        ResponseEntity<LoginResponse> expected = ResponseEntity.ok(body);

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(LoginResponse.class)
        )).thenReturn(expected);

        ResponseEntity<LoginResponse> actual = api.login(request);

        assertSame(expected, actual);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<HttpEntity> entityCaptor = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).exchange(
                urlCaptor.capture(),
                eq(HttpMethod.POST),
                entityCaptor.capture(),
                eq(LoginResponse.class)
        );

        assertEquals(
                "https://integral.example/v2/sso/login",
                urlCaptor.getValue()
        );
        assertSame(request, entityCaptor.getValue().getBody());
    }

    @Test
    void rateEnquiryLogin_usesDedicatedNonHmacRestTemplate() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");
        when(endpointsConfig.getSsoLogin()).thenReturn("/v2/sso/login");

        FxIntegralLoginApi api = new FxIntegralLoginApi(
                applicationConfig,
                endpointsConfig,
                restTemplate);

        LoginRequest request = new LoginRequest();
        request.setUser("u");
        request.setPass("p");
        request.setOrg("o");

        ResponseEntity<LoginResponse> expected =
                ResponseEntity.ok(new LoginResponse());

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(LoginResponse.class)
        )).thenReturn(expected);

        ResponseEntity<LoginResponse> actual =
                api.loginForRateEnquiry(request);

        assertSame(expected, actual);

        verify(restTemplate).exchange(
                eq("https://integral.example/v2/sso/login"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(LoginResponse.class)
        );
    }
}
